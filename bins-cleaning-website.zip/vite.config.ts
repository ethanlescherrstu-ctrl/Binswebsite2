import { defineConfig } from "vite";
import { tanstackStart } from "@tanstack/react-start/plugin/vite";
import viteReact from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import tsConfigPaths from "vite-tsconfig-paths";
import { nitro } from "nitro/vite";

/**
 * Plain Vite config — no Lovable wrapper.
 *
 * Deploy target is chosen at build time with the NITRO_PRESET env var.
 * Default is "node-server" (a normal Node.js server: VPS, Docker, Render, Railway, Fly.io…).
 * Examples:
 *   NITRO_PRESET=cloudflare-module npm run build   # Cloudflare Workers
 *   NITRO_PRESET=vercel            npm run build   # Vercel
 *   NITRO_PRESET=netlify           npm run build   # Netlify
 * Full list: https://nitro.build/deploy
 */
export default defineConfig(({ command }) => ({
  plugins: [
    tailwindcss(),
    tsConfigPaths({ projects: ["./tsconfig.json"] }),
    tanstackStart({
      // Use src/server.ts (our SSR error wrapper) as the server entry.
      server: { entry: "server" },
      importProtection: {
        behavior: "error",
        client: { files: ["**/server/**"], specifiers: ["server-only"] },
      },
    }),
    viteReact(),
    // Nitro packages the server output; only needed for production builds.
    ...(command === "build" ? [nitro({ preset: process.env.NITRO_PRESET || "node-server" })] : []),
  ],
  css: { transformer: "lightningcss" },
  resolve: {
    alias: { "@": `${process.cwd()}/src` },
    dedupe: [
      "react",
      "react-dom",
      "react/jsx-runtime",
      "react/jsx-dev-runtime",
      "@tanstack/react-query",
      "@tanstack/query-core",
    ],
  },
  server: { host: true, port: 8080 },
}));
