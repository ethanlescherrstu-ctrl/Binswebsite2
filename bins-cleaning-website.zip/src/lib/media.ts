/**
 * Central place for every image/video that is NOT bundled by Vite.
 *
 * Files live in /public/media and are served at /media/<file>.
 * To move big files (videos) to a CDN or object storage later, set
 * VITE_MEDIA_BASE_URL (e.g. https://media.yourdomain.com) and nothing else changes.
 *
 * This file is generated from scripts/media.manifest.json. Each export is an
 * object with a `url` field so existing `<img src={x.url}>` code keeps working.
 */
const BASE = ((import.meta.env.VITE_MEDIA_BASE_URL as string | undefined) ?? "/media").replace(/\/$/, "");

const media = (file: string) => ({ url: `${BASE}/${file}` });

export const extFinalWalkthroughJpg = media("ext-final-walkthrough.jpg");
export const extInspectPrepJpg = media("ext-inspect-prep.jpg");
export const extRinseDetailJpg = media("ext-rinse-detail.jpg");
export const extScrubLoosenJpg = media("ext-scrub-loosen.jpg");
export const exteriorHeroMov = media("exterior-hero.mp4");
export const finishedHomeMov = media("finished-home.mp4");
export const glassMirrorGymJpg = media("glass-mirror-gym.jpg");
export const glassShowerPartitionJpg = media("glass-shower-partition.jpg");
export const glassWineCabinetJpg = media("glass-wine-cabinet.jpg");
export const heroVideoMov = media("hero-video.mp4");
export const interiorHeroMov = media("interior-hero.mp4");
export const interiorMopSqueegeePng = media("interior-mop-squeegee.png");
export const interiorProtectJpg = media("interior-protect.jpg");
export const interiorSillsTracksBJpg = media("interior-sills-tracks-b.jpg");
export const interiorSqueegeeBMov = media("interior-squeegee-b.mp4");
export const interiorSqueegeeMp4 = media("interior-squeegee.mp4");
export const recentHome1Jpg = media("recent-home-1.jpg");
export const recentHome10Jpg = media("recent-home-10.jpg");
export const recentHome11Jpg = media("recent-home-11.jpg");
export const recentHome2Jpg = media("recent-home-2.jpg");
export const recentHome3Jpg = media("recent-home-3.jpg");
export const recentHome4Jpg = media("recent-home-4.jpg");
export const recentHome5Jpg = media("recent-home-5.jpg");
export const recentHome6Jpg = media("recent-home-6.jpg");
export const recentHome7Jpg = media("recent-home-7.jpg");
export const recentHome8Jpg = media("recent-home-8.jpg");
export const recentHome9Jpg = media("recent-home-9.jpg");
export const serviceCommercialCleaningPng = media("service-commercial-cleaning.png");
export const serviceExteriorWindowsPng = media("service-exterior-windows.png");
export const serviceGutterCleaningPng = media("service-gutter-cleaning.png");
export const serviceInteriorWindowsPng = media("service-interior-windows.png");
export const serviceScreenCleaningPng = media("service-screen-cleaning.png");
export const serviceSolarPanelPng = media("service-solar-panel.png");
export const stepDriesSpotFreeJpg = media("step-dries-spot-free.jpg");
export const stepLoosenGrimeJpg = media("step-loosen-grime.jpg");
export const stepReachPng = media("step-reach.png");
export const whatsIncludedMov = media("whats-included.mp4");
