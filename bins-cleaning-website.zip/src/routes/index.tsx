import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import * as React from "react";
import {
  ArrowLeft,
  ArrowRight,
  Star,
  Leaf,
  ShieldCheck,
  Clock,
  Sparkles,
  Droplets,
  Wind,
  Wrench,
  Menu,
  X,
  Phone,
  Mail,
  MapPin,
  Instagram,
  Facebook,
  ChevronDown,
  CalendarCheck,
  Truck,
  ShowerHead,
  CheckCircle2,
  Home as HomeIcon,
  Building2,
  Grid3x3,
  Frame,
  Sun,
  CloudRain,
} from "lucide-react";

import heroBin from "@/assets/hero-bin.jpg";
import { heroVideoMov as heroVideo } from "@/lib/media";
import svcResidential from "@/assets/service-residential.jpg";
import svcCommercial from "@/assets/service-commercial.jpg";
import svcDumpster from "@/assets/service-dumpster.jpg";
import svcRecycling from "@/assets/service-recycling.jpg";
import svcGreen from "@/assets/service-green.jpg";
import svcOdour from "@/assets/service-odour.jpg";
import { serviceExteriorWindowsPng as svcExterior } from "@/lib/media";
import { serviceInteriorWindowsPng as svcInterior } from "@/lib/media";
import { serviceScreenCleaningPng as svcScreen } from "@/lib/media";
import { serviceSolarPanelPng as svcSolar } from "@/lib/media";
import { recentHome1Jpg as recentHome1 } from "@/lib/media";
import { recentHome2Jpg as recentHome2 } from "@/lib/media";
import { recentHome3Jpg as recentHome3 } from "@/lib/media";
import { recentHome4Jpg as recentHome4 } from "@/lib/media";
import { recentHome5Jpg as recentHome5 } from "@/lib/media";
import { recentHome6Jpg as recentHome6 } from "@/lib/media";
import { recentHome7Jpg as recentHome7 } from "@/lib/media";
import { recentHome8Jpg as recentHome8 } from "@/lib/media";
import { recentHome9Jpg as recentHome9 } from "@/lib/media";
import { recentHome10Jpg as recentHome10 } from "@/lib/media";
import { recentHome11Jpg as recentHome11 } from "@/lib/media";
import { serviceCommercialCleaningPng as svcCommercialClean } from "@/lib/media";
import { serviceGutterCleaningPng as svcGutter } from "@/lib/media";
import beforeImg from "@/assets/before.jpg";
import afterImg from "@/assets/after.jpg";
import { finishedHomeMov as finishedHomeVideo } from "@/lib/media";
import { interiorSqueegeeMp4 as interiorSqueegeeVideo } from "@/lib/media";
export const Route = createFileRoute("/")({
  component: Home,
});

/* ---------------- Navigation ---------------- */
function Nav() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const links = [
    ["Home", "#home"],
    ["Services", "#services"],
    ["About", "#about"],
    ["Gallery", "#gallery"],
    ["Reviews", "#reviews"],
    ["FAQ", "#faq"],
    ["Contact", "#contact"],
  ] as const;

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-500 ${
        scrolled
          ? "backdrop-blur-xl bg-navy-deep/80 border-b border-white/5"
          : "bg-transparent"
      }`}
    >
      <div className="section-container flex h-20 items-center justify-between gap-4">
        <a href="#home" className="flex items-baseline gap-1.5 text-white shrink-0">
          <span className="text-3xl font-extrabold tracking-tight leading-none">BINS</span>
          <span className="text-sm font-medium tracking-[0.25em] text-teal">CLEANING</span>
        </a>

        <nav className="hidden lg:flex items-center gap-1">
          {links.map(([label, href]) => (
            <a
              key={label}
              href={href}
              className="px-4 py-2 text-sm font-medium text-white/75 hover:text-white transition-colors rounded-full hover:bg-white/5"
            >
              {label}
            </a>
          ))}
        </nav>

        <div className="hidden md:flex items-center gap-3 shrink-0">
          <a href="#contact" className="btn-ghost-light text-sm">Get Quote</a>
          <a href="#contact" className="btn-teal text-sm">Book Now</a>
        </div>

        <button
          className="lg:hidden text-white p-2"
          onClick={() => setOpen((v) => !v)}
          aria-label="Toggle menu"
        >
          {open ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {open && (
        <div className="lg:hidden backdrop-blur-xl bg-navy-deep/95 border-t border-white/5 animate-fade-up">
          <div className="section-container py-6 flex flex-col gap-1">
            {links.map(([label, href]) => (
              <a
                key={label}
                href={href}
                onClick={() => setOpen(false)}
                className="py-3 text-base text-white/85 hover:text-teal-bright"
              >
                {label}
              </a>
            ))}
            <div className="mt-4 flex flex-col gap-3">
              <a href="#contact" onClick={() => setOpen(false)} className="btn-ghost-light justify-center">
                Get Quote
              </a>
              <a href="#contact" onClick={() => setOpen(false)} className="btn-teal justify-center">
                Book Now
              </a>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}

/* ---------------- Hero ---------------- */
function Hero() {
  return (
    <section id="home" className="relative min-h-screen w-full overflow-hidden bg-navy-deep">
      <video
        src={heroVideo.url}
        poster={heroBin}
        autoPlay
        muted
        loop
        playsInline
        preload="auto"
        aria-label="Premium residential window cleaning in Calgary"
        className="absolute inset-0 h-full w-full object-cover scale-105"
      />
      <div
        className="absolute inset-0"
        style={{ background: "var(--gradient-hero)" }}
      />
      <div className="absolute inset-0 bg-navy-deep/50" />

      <div className="relative z-10 section-container flex min-h-screen flex-col items-start justify-center text-left pt-24 pb-32 md:pl-[8%] lg:pl-[12%]">
        <div className="animate-fade-up text-xs font-semibold tracking-[0.25em] text-teal-bright uppercase">
          SERVICING CALGARY & SURROUNDING AREA
        </div>

        <h1
          className="mt-6 max-w-2xl text-white text-2xl sm:text-3xl md:text-[2.4rem] lg:text-[2.9rem] font-extrabold leading-[1.05] animate-fade-up"
          style={{ animationDelay: "0.1s" }}
        >
          Calgary's #1 Trusted
          <br />
          <span
            className="bg-clip-text text-transparent"
            style={{ backgroundImage: "var(--gradient-teal)" }}
          >
            Window Cleaners.
          </span>
        </h1>

        <p
          className="mt-6 max-w-xl text-sm md:text-base text-white/75 font-light leading-relaxed animate-fade-up"
          style={{ animationDelay: "0.2s" }}
        >
          Crystal-clear windows that stay cleaner 6x longer, trusted by 500+ Calgary homeowners.
        </p>


        <div
          className="mt-6 flex items-center animate-fade-up"
          style={{ animationDelay: "0.3s" }}
        >
          <a
            href="#reviews"
            className="group google-review-badge relative inline-flex items-center gap-2 rounded-full bg-white/10 backdrop-blur px-3.5 py-1.5 text-xs text-white shadow-lg"
          >
            <span className="flex items-center gap-0.5 text-[#FBBC04] text-sm leading-none">
              ★★★★★
            </span>
            <span className="font-semibold">5.0</span>
            <span className="text-white/80">on Google</span>
          </a>
        </div>

        <div
          className="mt-7 flex flex-wrap items-center gap-3 animate-fade-up"
          style={{ animationDelay: "0.4s" }}
        >
          <a href="#contact" className="btn-teal text-xs px-4 py-2">
            Get My Free Quote <ArrowRight size={12} />
          </a>
          <a href="#contact" className="btn-ghost-light text-xs px-4 py-2">
            Contact Us
          </a>
        </div>
      </div>


      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 flex flex-col items-center gap-2 text-white/70">
        <span className="text-[10px] tracking-[0.35em] font-semibold">SCROLL</span>
        <div className="h-10 w-6 rounded-full border border-white/40 flex items-start justify-center p-1.5">
          <span className="h-2 w-1 rounded-full bg-white animate-scroll-hint" />
        </div>
      </div>
    </section>
  );
}

/* ---------------- Trust Stats ---------------- */
function useCountUp(target: number, trigger: boolean, duration = 1600) {
  const [value, setValue] = useState(0);
  useEffect(() => {
    if (!trigger) return;
    let raf = 0;
    const start = performance.now();
    const step = (t: number) => {
      const p = Math.min((t - start) / duration, 1);
      const eased = 1 - Math.pow(1 - p, 3);
      setValue(Math.round(eased * target));
      if (p < 1) raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [target, trigger, duration]);
  return value;
}

function TrustStats() {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    if (!ref.current) return;
    const io = new IntersectionObserver(
      ([e]) => e.isIntersecting && setVisible(true),
      { threshold: 0.25 }
    );
    io.observe(ref.current);
    return () => io.disconnect();
  }, []);

  const homes = useCountUp(500, visible);
  const reviews = useCountUp(205, visible);
  const sat = useCountUp(100, visible);
  const longer = useCountUp(6, visible);

  const badges = [
    { icon: ShieldCheck, label: "$2M Liability · Licensed & Insured" },
    { icon: CheckCircle2, label: "100% Satisfaction Guarantee" },
    { icon: Droplets, label: "Pure-Water System" },
    { icon: MapPin, label: "Serving Calgary & Area" },
  ];

  const stats = [
    { value: `${homes}+`, label: "Homes Serviced" },
    { value: `${reviews}+`, label: "5-Star Reviews" },
    { value: `${sat}%`, label: "Satisfaction Guarantee" },
    { value: `${longer}x`, label: "Longer Between Cleans" },
  ];

  return (
    <section ref={ref} className="relative bg-brand-bg">
      {/* Top divider — full bleed */}
      <div className="h-px w-full bg-white/10" />

      <div className="section-container">
        {/* Badges row */}
        <div className="grid grid-cols-2 md:grid-cols-4 divide-x divide-white/10">
          {badges.map(({ icon: Icon, label }) => (
            <div
              key={label}
              className="flex items-center justify-center gap-2.5 px-4 py-5 text-center text-sm text-white/85"
            >
              <Icon size={16} className="shrink-0 text-teal-bright" />
              <span className="font-medium">{label}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Middle divider — full bleed */}
      <div className="h-px w-full bg-white/10" />

      <div className="section-container">
        {/* Stats row */}
        <div className="grid grid-cols-2 md:grid-cols-4 py-14 md:py-20">
          {stats.map((s) => (
            <div key={s.label} className="px-4 text-center">
              <div
                className="text-3xl md:text-4xl lg:text-5xl font-extrabold bg-clip-text text-transparent"
                style={{ backgroundImage: "var(--gradient-teal)" }}
              >
                {s.value}
              </div>
              <div className="mt-4 text-xs md:text-sm text-white/60 font-light tracking-wide">
                {s.label}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Bottom divider — full bleed */}
      <div className="h-px w-full bg-white/10" />
    </section>
  );
}



/* ---------------- Services ---------------- */
function Services() {
  const items = [
    {
      slug: "exterior-window-cleaning",
      img: svcExterior.url,
      icon: Grid3x3,
      title: "Exterior Window Cleaning",
      desc: "Hard-water spots, grime and pollen gone. Crystal-clear glass on every exterior pane.",
    },
    {
      slug: "interior-window-cleaning",
      img: svcInterior.url,
      icon: Frame,
      title: "Interior Window Cleaning",
      desc: "Shoe covers on, sills and tracks detailed, light pouring back into your rooms.",
    },
    {
      slug: "screen-cleaning",
      img: svcScreen.url,
      icon: Wind,
      title: "Screen Cleaning",
      desc: "Screens removed, hand-washed, dried and re-fitted so airflow and views stay fresh.",
    },
    {
      slug: "commercial-cleaning",
      img: svcCommercialClean.url,
      icon: Building2,
      title: "Commercial Cleaning",
      desc: "Storefronts, car dealerships, offices & strata — streak-free, after-hours, fully insured.",
    },
    {
      slug: "solar-panel-cleaning",
      img: svcSolar.url,
      icon: Sparkles,
      title: "Solar Panel Cleaning",
      desc: "Dust and film cut output. A safe, residue-free purified-water clean restores efficiency.",
    },
    {
      slug: "gutter-cleaning",
      img: svcGutter.url,
      icon: CloudRain,
      title: "Gutter Cleaning",
      desc: "Debris flushed, downspouts cleared and flow restored — protecting your roof, siding and foundation.",
    },
  ];

  return (
    <section id="services" className="bg-brand-bg py-24 md:py-36">
      <div className="section-container">
        <div className="max-w-3xl mx-auto text-center">
          <span className="text-xs font-semibold tracking-[0.25em] text-teal uppercase">
            What We Do
          </span>
          <h2 className="mt-4 text-4xl md:text-6xl text-white leading-[1.05]">
            Window cleaning,
            <br />
            <span className="text-teal">done every way</span>
          </h2>
          <p className="mt-6 text-base md:text-lg text-white/70 font-light leading-relaxed">
            Residential & commercial window cleaning across Calgary — exterior & interior glass,
            screens, solar panels, storefronts and dealerships. One meticulous crew, every
            spotless service.
          </p>
        </div>

        <div className="mt-16 grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8 max-w-6xl mx-auto">
          {items.map((it) => {
            const Icon = it.icon;
            return (
              <Link
                key={it.title}
                to="/services/$slug"
                params={{ slug: it.slug }}
                className="group relative block overflow-hidden rounded-2xl aspect-[4/3] lg:aspect-[16/10] shadow-[var(--shadow-card)] transition-all duration-500 hover:-translate-y-1 hover:shadow-[0_30px_80px_-20px_oklch(0.19_0.03_240_/_0.45)]"
              >
                <img
                  src={it.img}
                  alt={it.title}
                  loading="lazy"
                  className="absolute inset-0 h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-navy-deep/95 via-navy-deep/60 to-navy-deep/10" />
                <div className="absolute top-4 left-4 sm:top-6 sm:left-6">
                  <div className="grid h-9 w-9 lg:h-12 lg:w-12 place-items-center rounded-xl bg-gradient-to-br from-teal-bright to-teal shadow-lg">
                    <Icon size={18} className="text-white lg:hidden" strokeWidth={2.25} />
                    <Icon size={22} className="text-white hidden lg:block" strokeWidth={2.25} />
                  </div>
                </div>
                <div className="absolute bottom-0 left-0 right-0 p-4 lg:p-7 xl:p-8">
                  <h3 className="text-lg lg:text-2xl xl:text-3xl text-white font-bold leading-tight">{it.title}</h3>
                  <p className="mt-2 lg:mt-3 text-xs lg:text-base text-white/80 font-light leading-snug lg:leading-relaxed max-w-xl line-clamp-3 lg:line-clamp-none">{it.desc}</p>
                  <span className="mt-3 lg:mt-5 inline-flex items-center gap-2 text-teal-bright font-semibold text-xs lg:text-sm">
                    Explore service
                    <ArrowRight size={14} className="transition-transform group-hover:translate-x-1" />
                  </span>
                </div>
              </Link>
            );
          })}
        </div>
      </div>
    </section>
  );
}

/* ---------------- Why Choose Us ---------------- */
function WhyUs() {
  const rows = [
    { icon: Droplets, title: "Pure-Water Reverse Osmosis", desc: "Mineral-free water reaches the tallest windows and dries to a spotless, streak-free finish — no ladders, no residue." },
    { icon: Sparkles, title: "Hand-Finished by Mop & Squeegee", desc: "Every reachable window is cleaned traditionally by hand. A craftsman's finish you can only feel through experience." },
    { icon: Frame, title: "Frames, Tracks & Sills Included", desc: "We detail every edge, corner, and channel — not just the glass — so the entire window looks brand new." },
    { icon: Grid3x3, title: "Screens Gently Cleaned", desc: "Screens are removed, washed, dried, and refit to restore clear airflow and remove trapped dust and pollen." },
    { icon: Wind, title: "Cobwebs & Debris Removed", desc: "Insects, leaves, pollen, and built-up debris cleared from every frame and corner — inside and out." },
    { icon: ShieldCheck, title: "Local, Licensed & Insured", desc: "Calgary-based, fully insured, and accountable. Best In Neighbourhood Services — it's in the name." },
  ];

  return (
    <section id="about" className="bg-brand-bg-alt py-24 md:py-36">
      <div className="section-container">
        <div className="max-w-2xl">
          <span className="text-xs font-semibold tracking-[0.25em] text-teal uppercase">
            WHY CHOOSE BINS
          </span>
          <h2 className="mt-4 text-4xl md:text-6xl text-white">
            Brighter windows,
            <br />
            <span className="text-teal">every detail considered.</span>
          </h2>
        </div>

        <div className="mt-16 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {rows.map(({ icon: Icon, title, desc }) => (
            <div
              key={title}
              className="group rounded-3xl bg-card p-8 shadow-[var(--shadow-soft)] transition-all duration-500 hover:-translate-y-1 hover:shadow-[var(--shadow-card)]"
            >
              <div
                className="grid h-14 w-14 place-items-center rounded-2xl text-white"
                style={{ background: "var(--gradient-teal)" }}
              >
                <Icon size={26} />
              </div>
              <h3 className="mt-6 text-xl text-white">{title}</h3>
              <p className="mt-3 text-white/70 font-light leading-relaxed">{desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------------- Process ---------------- */
function Process() {
  const steps = [
    { icon: CalendarCheck, title: "Book Online", desc: "Request a quote or reserve your date in under 60 seconds." },
    { icon: Truck, title: "We Arrive On Time", desc: "A uniformed local crew arrives ready to protect your home." },
    { icon: ShowerHead, title: "Detailed Window Clean", desc: "Glass, frames, tracks, sills, and screens — inside and out." },
    { icon: Sparkles, title: "Streak-Free Finish", desc: "A final inspection ensures every window is spotless." },
  ];
  return (
    <section className="bg-navy-deep py-24 md:py-36 text-white">
      <div className="section-container">
        <div className="max-w-2xl mx-auto text-center">
          <span className="text-xs font-semibold tracking-[0.25em] text-teal-bright uppercase">
            The Process
          </span>
          <h2 className="mt-4 text-4xl md:text-6xl text-white">
            Simple.
            <br />
            <span className="text-teal-bright">Effortless. Spotless.</span>
          </h2>
        </div>

        <div className="mt-20 grid grid-cols-1 md:grid-cols-4 gap-6 md:gap-4 relative">
          {steps.map(({ icon: Icon, title, desc }, i) => (
            <div key={title} className="relative text-center">
              <div className="relative mx-auto grid h-20 w-20 place-items-center rounded-3xl glass-card animate-float" style={{ animationDelay: `${i * 0.2}s` }}>
                <Icon size={30} className="text-teal-bright" />
                <span className="absolute -top-2 -right-2 grid h-7 w-7 place-items-center rounded-full text-xs font-bold text-navy-deep" style={{ background: "var(--gradient-teal)" }}>
                  {i + 1}
                </span>
              </div>
              <h3 className="mt-6 text-xl">{title}</h3>
              <p className="mt-2 text-white/60 font-light text-sm leading-relaxed max-w-[220px] mx-auto">{desc}</p>
              {i < steps.length - 1 && (
                <div className="hidden md:block absolute top-10 left-[calc(50%+3rem)] right-[-3rem] h-px bg-gradient-to-r from-teal/40 to-transparent" />
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------------- See It In Action (video + before/after) ---------------- */
function FinishedHome() {
  const videoRef = useRef<HTMLVideoElement>(null);



  return (
    <section className="bg-brand-bg py-24 md:py-36">
      <div className="section-container">
        <div className="max-w-2xl mx-auto text-center">
          <span className="text-xs font-semibold tracking-[0.25em] text-teal uppercase">
            See It In Action
          </span>
          <h2 className="mt-4 text-4xl md:text-6xl text-white">
            Real cleans, real
            <span className="text-teal"> Calgary homes.</span>
          </h2>
          <p className="mt-6 text-white/70 font-light">
            Pure-water technology, meticulous hand detailing, and flawlessly finished windows — inside and out.
          </p>
        </div>

        <div className="mt-12 mx-auto max-w-5xl">
          {/* Live cleaning video */}
          <div className="relative aspect-[16/9] overflow-hidden rounded-[2rem] shadow-[var(--shadow-card)]">
            <video
              ref={videoRef}
              src={finishedHomeVideo.url}
              autoPlay
              muted
              loop
              playsInline
              className="absolute inset-0 h-full w-full object-cover"
            />
            <div className="absolute bottom-4 left-4 rounded-full bg-black/50 backdrop-blur px-3 py-1 text-xs font-semibold tracking-widest text-white uppercase">
              Live Cleaning
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}


function BeforeAfter() {
  const [pos, setPos] = useState(50);
  const ref = useRef<HTMLDivElement>(null);
  const dragging = useRef(false);

  const move = (clientX: number) => {
    const el = ref.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    const p = ((clientX - r.left) / r.width) * 100;
    setPos(Math.max(0, Math.min(100, p)));
  };

  useEffect(() => {
    const onMove = (e: MouseEvent | TouchEvent) => {
      if (!dragging.current) return;
      const x = "touches" in e ? e.touches[0].clientX : (e as MouseEvent).clientX;
      move(x);
    };
    const onUp = () => (dragging.current = false);
    window.addEventListener("mousemove", onMove);
    window.addEventListener("mouseup", onUp);
    window.addEventListener("touchmove", onMove);
    window.addEventListener("touchend", onUp);
    return () => {
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("mouseup", onUp);
      window.removeEventListener("touchmove", onMove);
      window.removeEventListener("touchend", onUp);
    };
  }, []);

  return (
    <section className="bg-brand-bg py-24 md:py-36">
      <div className="section-container">
        <div className="max-w-2xl mx-auto text-center">
          <span className="text-xs font-semibold tracking-[0.25em] text-teal uppercase">
            Before & After
          </span>
          <h2 className="mt-4 text-4xl md:text-6xl text-white">
            See the
            <span className="text-teal"> difference.</span>
          </h2>
          <p className="mt-6 text-white/70 font-light">Drag the handle to reveal a crystal-clear transformation.</p>
        </div>

        <div
          ref={ref}
          className="relative mt-12 mx-auto aspect-[3/2] max-w-5xl overflow-hidden rounded-[2rem] shadow-[var(--shadow-card)] select-none cursor-ew-resize"
          onMouseDown={(e) => { dragging.current = true; move(e.clientX); }}
          onTouchStart={(e) => { dragging.current = true; move(e.touches[0].clientX); }}
        >
          <img src={afterImg} alt="Windows after cleaning" className="absolute inset-0 h-full w-full object-cover" />
          <div
            className="absolute inset-0 h-full overflow-hidden"
            style={{ width: `${pos}%` }}
          >
            <img
              src={beforeImg}
              alt="Windows before cleaning"
              className="absolute inset-0 h-full object-cover"
              style={{ width: `${(100 / pos) * 100}%`, maxWidth: "none" }}
            />
          </div>

          <div className="absolute top-6 left-6 rounded-full glass-card px-4 py-1.5 text-xs font-semibold text-white tracking-[0.2em]">
            BEFORE
          </div>
          <div className="absolute top-6 right-6 rounded-full px-4 py-1.5 text-xs font-semibold text-navy-deep tracking-[0.2em]" style={{ background: "var(--gradient-teal)" }}>
            AFTER
          </div>

          <div
            className="absolute inset-y-0 w-1 bg-white shadow-[0_0_20px_rgba(0,0,0,0.5)]"
            style={{ left: `${pos}%`, transform: "translateX(-50%)" }}
          >
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 grid h-14 w-14 place-items-center rounded-full bg-white shadow-xl">
              <div className="flex gap-0.5">
                <ChevronDown size={18} className="rotate-90 text-navy-deep" />
                <ChevronDown size={18} className="-rotate-90 text-navy-deep" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ---------------- Recent Work ---------------- */
function Gallery() {
  const items = [
    { src: recentHome1.url, alt: "Calgary two-story home with freshly cleaned windows" },
    { src: recentHome2.url, alt: "Calgary backyard windows spotless after cleaning" },
    { src: recentHome3.url, alt: "Calgary home front with streak-free windows" },
    { src: recentHome6.url, alt: "Calgary luxury home back exterior with spotless windows at sunset" },
    { src: recentHome5.url, alt: "Calgary two-story home front with freshly cleaned windows at dusk" },
    { src: recentHome4.url, alt: "Calgary bungalow with sparkling clean windows" },
    { src: recentHome7.url, alt: "Calgary bi-level home with newly cleaned windows on a summer evening" },
    { src: recentHome8.url, alt: "Calgary two-storey home side profile with clean windows" },
    { src: recentHome9.url, alt: "Calgary home exterior detail after window clean" },
    { src: recentHome10.url, alt: "Calgary home exterior with freshly cleaned windows after BINS Pure-Clean System" },
    { src: recentHome11.url, alt: "Calgary bungalow front exterior with spotless windows after cleaning" },
  ];
  return (
    <section id="gallery" className="bg-brand-bg py-24 md:py-32">
      <div>
        <div className="max-w-3xl mx-auto text-center px-4">
          <span className="text-xs font-semibold tracking-[0.25em] text-teal-bright uppercase">
            Our Recent Work
          </span>
          <h2 className="mt-6 text-4xl md:text-6xl font-extrabold leading-[1.05] text-white">
            Bringing out the best in{" "}
            <span className="text-teal-bright">Calgary homes</span>
          </h2>
          <p className="mt-6 text-base md:text-lg text-white/70 font-light leading-relaxed">
            A look at recent exterior window cleans across the city — every pane finished with the BINS Pure-Clean System™.
          </p>
        </div>

        <div className="relative mt-16 px-1 sm:px-2">
          <div
            className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2 md:gap-3"
            style={{
              WebkitMaskImage:
                "linear-gradient(to right, transparent 0, rgba(0,0,0,0.35) 1.5%, #000 5%, #000 95%, rgba(0,0,0,0.35) 98.5%, transparent 100%)",
              maskImage:
                "linear-gradient(to right, transparent 0, rgba(0,0,0,0.35) 1.5%, #000 5%, #000 95%, rgba(0,0,0,0.35) 98.5%, transparent 100%)",
            }}
          >
            {items.map((img, i) => (
              <div
                key={i}
                className="group relative overflow-hidden rounded-2xl border border-white/5 shadow-[var(--shadow-card)] aspect-[4/3]"
              >
                <img
                  src={img.src}
                  alt={img.alt}
                  loading="lazy"
                  className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              </div>
            ))}
          </div>
          <div className="pointer-events-none absolute inset-y-0 left-0 w-24 md:w-32 bg-gradient-to-r from-brand-bg to-transparent backdrop-blur-[2px]" style={{ WebkitMaskImage: "linear-gradient(to right, #000, transparent)", maskImage: "linear-gradient(to right, #000, transparent)" }} />
          <div className="pointer-events-none absolute inset-y-0 right-0 w-24 md:w-32 bg-gradient-to-l from-brand-bg to-transparent backdrop-blur-[2px]" style={{ WebkitMaskImage: "linear-gradient(to left, #000, transparent)", maskImage: "linear-gradient(to left, #000, transparent)" }} />
        </div>
      </div>


    </section>
  );
}


/* ---------------- Reviews ---------------- */
function GoogleG({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 48 48" className={className} aria-hidden="true">
      <path fill="#4285F4" d="M45.12 24.5c0-1.56-.14-3.06-.4-4.5H24v8.51h11.84c-.51 2.75-2.06 5.08-4.39 6.64v5.52h7.11c4.16-3.83 6.56-9.47 6.56-16.17z"/>
      <path fill="#34A853" d="M24 46c5.94 0 10.92-1.97 14.56-5.33l-7.11-5.52c-1.97 1.32-4.49 2.1-7.45 2.1-5.73 0-10.58-3.87-12.31-9.07H4.34v5.7C7.96 41.07 15.4 46 24 46z"/>
      <path fill="#FBBC04" d="M11.69 28.18c-.44-1.32-.69-2.73-.69-4.18s.25-2.86.69-4.18v-5.7H4.34C2.85 17.09 2 20.45 2 24s.85 6.91 2.34 9.88l7.35-5.7z"/>
      <path fill="#EA4335" d="M24 10.75c3.23 0 6.13 1.11 8.41 3.29l6.31-6.31C34.91 4.18 29.93 2 24 2 15.4 2 7.96 6.93 4.34 14.12l7.35 5.7C13.42 14.62 18.27 10.75 24 10.75z"/>
    </svg>
  );
}

function Reviews() {
  const list = [
    {
      name: "Sarah M.",
      loc: "Aspen Woods, Calgary",
      text: "Every window in our home looks brand new. What impressed me most was the attention to the frames, tracks, and sills — not just the glass. Truly premium work.",
      initial: "S",
      color: "#4285F4",
    },
    {
      name: "David T.",
      loc: "Mahogany, Calgary",
      text: "Booked them for our two-storey and the pure-water system reached everything perfectly. No ladders leaning on the house, no streaks. Signed up for seasonal cleans on the spot.",
      initial: "D",
      color: "#EA4335",
    },
    {
      name: "Priya K.",
      loc: "Bridgeland, Calgary",
      text: "They cleaned the screens, wiped every sill, and cleared out years of cobwebs I couldn't reach. The house feels genuinely brighter. Highly recommend.",
      initial: "P",
      color: "#FBBC04",
    },
    {
      name: "Michael R.",
      loc: "Tuscany, Calgary",
      text: "Professional from the first call to the final walk-through. Punctual, tidy, and the results speak for themselves. Best window cleaning we've ever had.",
      initial: "M",
      color: "#34A853",
    },
    {
      name: "Jenna L.",
      loc: "Altadore, Calgary",
      text: "I've tried three other companies over the years. BINS is on a completely different level — thorough, respectful of the property, and genuinely friendly.",
      initial: "J",
      color: "#4285F4",
    },
    {
      name: "Ahmed H.",
      loc: "Evanston, Calgary",
      text: "Booked online in under a minute and had the team out within the week. Every pane sparkles and the price was exactly what was quoted. No surprises.",
      initial: "A",
      color: "#EA4335",
    },
    {
      name: "Rachel B.",
      loc: "Inglewood, Calgary",
      text: "Our old character home has tricky storm windows and they handled them like pros. Nothing was skipped, nothing was rushed. Absolutely worth it.",
      initial: "R",
      color: "#FBBC04",
    },
    {
      name: "Kevin O.",
      loc: "Signal Hill, Calgary",
      text: "Showed up on time, wore booties inside, and left the place cleaner than they found it. The windows honestly look invisible now.",
      initial: "K",
      color: "#34A853",
    },
    {
      name: "Nicole F.",
      loc: "West Springs, Calgary",
      text: "Booked their solar panel clean too — noticed a jump in output within days. Great crew, great communication, great result.",
      initial: "N",
      color: "#4285F4",
    },
  ];

  const [index, setIndex] = React.useState(0);
  const total = list.length;
  const TRANSITION_MS = 850;
  const isAnimating = React.useRef(false);
  const wheelAccum = React.useRef(0);
  const wheelReset = React.useRef<number | null>(null);
  const [paused, setPaused] = React.useState(false);


  const advance = React.useCallback(
    (dir: number) => {
      if (isAnimating.current) return;
      isAnimating.current = true;
      setIndex((i) => (i + dir + total) % total);
      window.setTimeout(() => {
        isAnimating.current = false;
      }, TRANSITION_MS);
    },
    [total],
  );

  React.useEffect(() => {
    if (paused) return;
    const id = window.setInterval(() => advance(1), 5000);
    return () => window.clearInterval(id);
  }, [paused, advance]);

  const goTo = React.useCallback(
    (target: number) => {
      if (isAnimating.current || target === index) return;
      isAnimating.current = true;
      setIndex(target);
      window.setTimeout(() => {
        isAnimating.current = false;
      }, TRANSITION_MS);
    },
    [index],
  );

  const onWheel = (e: React.WheelEvent) => {
    const delta = Math.abs(e.deltaX) > Math.abs(e.deltaY) ? e.deltaX : e.deltaY;
    wheelAccum.current += delta;
    if (wheelReset.current) window.clearTimeout(wheelReset.current);
    wheelReset.current = window.setTimeout(() => {
      wheelAccum.current = 0;
    }, 180);
    const THRESHOLD = 60;
    if (Math.abs(wheelAccum.current) < THRESHOLD) return;
    if (isAnimating.current) return;
    const dir = wheelAccum.current > 0 ? 1 : -1;
    wheelAccum.current = 0;
    advance(dir);
  };

  const offsetOf = (i: number) => {
    let o = i - index;
    if (o > total / 2) o -= total;
    if (o < -total / 2) o += total;
    return o;
  };

  return (
    <section id="reviews" className="bg-navy-deep py-24 md:py-36 text-white overflow-hidden">
      <div className="section-container">
        <div className="max-w-2xl mx-auto text-center">
          <span className="text-xs font-semibold tracking-[0.25em] text-teal-bright uppercase">Reviews</span>
          <h2 className="mt-4 text-4xl md:text-6xl">
            Loved by Calgary
            <br />
            <span className="text-teal-bright">homeowners.</span>
          </h2>
          <div className="mt-6 inline-flex items-center gap-3 rounded-full glass-card px-5 py-2 text-sm">
            <span className="flex gap-0.5">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star key={i} size={16} className="fill-teal-bright text-teal-bright" />
              ))}
            </span>
            <span className="text-white/80">5.0 on Google · 205+ reviews</span>
          </div>
        </div>

        <div
          className="relative mt-16 mx-auto"
          style={{ perspective: "1800px", maxWidth: "1200px" }}
          onWheel={onWheel}
          onMouseEnter={() => setPaused(true)}
          onMouseLeave={() => setPaused(false)}
        >
          <div className="relative h-[440px] md:h-[400px]" style={{ transformStyle: "preserve-3d" }}>
            {list.map((r, i) => {
              const o = offsetOf(i);
              const abs = Math.abs(o);
              const hidden = abs > 2;
              const translateX = o * 320;
              const translateZ = -abs * 220;
              const rotateY = o * -22;
              const scale = 1 - abs * 0.06;
              const opacity = hidden ? 0 : abs === 2 ? 0.35 : abs === 1 ? 0.7 : 1;
              const zIndex = 100 - abs;
              return (
                <div
                  key={r.name}
                  className="absolute top-0 left-1/2 w-[340px] md:w-[380px]"
                  style={{
                    transform: `translate(-50%, 0) translate3d(${translateX}px, 0, ${translateZ}px) rotateY(${rotateY}deg) scale(${scale})`,
                    opacity,
                    zIndex,
                    transition:
                      "transform 850ms cubic-bezier(0.25, 1, 0.3, 1), opacity 700ms cubic-bezier(0.25, 1, 0.3, 1)",
                    pointerEvents: o === 0 ? "auto" : "none",
                    transformStyle: "preserve-3d",
                    willChange: "transform, opacity",
                  }}
                >
                  <div
                    className="glass-card p-8 flex flex-col h-[400px] md:h-[380px] relative"
                    style={{
                      background: "color-mix(in oklab, oklch(0.32 0.09 255) 78%, transparent)",
                      boxShadow:
                        o === 0
                          ? "0 30px 80px -20px oklch(0.68 0.12 190 / 0.35)"
                          : "0 20px 50px -20px oklch(0.1 0.02 240 / 0.6)",
                    }}
                  >
                    <GoogleG className="absolute top-6 right-6 h-6 w-6" />
                    <div className="flex items-center gap-3 pr-10">
                      <div
                        className="grid h-12 w-12 shrink-0 place-items-center rounded-full text-white font-bold text-base"
                        style={{ background: r.color }}
                      >
                        {r.initial}

                      </div>
                      <div className="min-w-0">
                        <div className="font-semibold truncate">{r.name}</div>
                        <div className="text-xs text-white/50">Google review</div>
                      </div>
                    </div>
                    <div className="mt-5 flex gap-0.5">
                      {Array.from({ length: 5 }).map((_, k) => (
                        <Star key={k} size={16} className="fill-[#FBBC04] text-[#FBBC04]" />
                      ))}
                    </div>
                    <p className="mt-4 text-white/85 font-light leading-relaxed flex-1">"{r.text}"</p>
                    <div className="text-xs text-white/40 mt-4">{r.loc}</div>
                  </div>
                </div>
              );
            })}

          </div>

          <div className="mt-8 flex items-center justify-center gap-4">
            <button
              onClick={() => advance(-1)}
              aria-label="Previous review"
              className="grid h-11 w-11 place-items-center rounded-full glass-card hover:bg-white/15 transition"
            >
              <ArrowLeft size={18} />
            </button>
            <div className="flex items-center gap-2">
              {list.map((_, i) => (
                <button
                  key={i}
                  onClick={() => goTo(i)}
                  aria-label={`Go to review ${i + 1}`}
                  className="h-1.5 rounded-full transition-all"
                  style={{
                    width: i === index ? 24 : 8,
                    background: i === index ? "var(--teal-bright)" : "rgba(255,255,255,0.25)",
                  }}
                />
              ))}
            </div>
            <button
              onClick={() => advance(1)}
              aria-label="Next review"
              className="grid h-11 w-11 place-items-center rounded-full glass-card hover:bg-white/15 transition"
            >
              <ArrowRight size={18} />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ---------------- CTA ---------------- */
function CTA() {
  return (
    <section className="relative overflow-hidden bg-navy-deep py-24 md:py-32">
      <div
        className="absolute inset-0 opacity-40"
        style={{
          background:
            "radial-gradient(60% 50% at 50% 50%, oklch(0.68 0.12 190 / 0.5), transparent 70%)",
        }}
      />
      <div className="relative section-container text-center">
        <h2 className="text-4xl md:text-6xl lg:text-7xl text-white">
          Ready for
          <span className="text-teal-bright"> crystal-clear windows?</span>
        </h2>
        <p className="mt-6 max-w-xl mx-auto text-white/70 font-light text-lg">
          Join hundreds of Calgary homeowners who trust BINS Cleaning for meticulous, edge-to-edge
          window care. Request your free quote in under a minute.
        </p>
        <div className="mt-10 flex flex-wrap justify-center gap-4">
          <a href="#contact" className="btn-teal text-base px-8 py-4">
            Book Online <ArrowRight size={18} />
          </a>
          <a href="#contact" className="btn-ghost-light text-base px-8 py-4">
            Get Free Quote
          </a>
        </div>
      </div>
    </section>
  );
}

/* ---------------- FAQ ---------------- */
function FAQ() {
  const qs = [
    { q: "What's included in a window cleaning service?", a: "Every service covers interior and exterior glass, window frames, tracks, sills, screens, edges, corners, and surrounding trim. We remove dust, pollen, cobwebs, insects, leaves, hard-water spotting, and built-up debris — leaving each window spotless from edge to edge." },
    { q: "How often should windows be professionally cleaned?", a: "Most Calgary homes benefit from a spring and fall clean. Homes near trees, construction, or busy roads often prefer quarterly service to stay ahead of pollen, dust, and mineral spotting." },
    { q: "How do you reach second-storey and high windows?", a: "We use waterfed reverse-osmosis poles that clean safely from the ground with mineral-free pure water. It reaches high and hard-to-access windows without ladders leaning on your home." },
    { q: "Do you clean by hand or by machine?", a: "Everything reachable is hand-finished with a traditional mop and squeegee — the professional standard for a truly streak-free finish. Higher and larger windows are finished with our pure-water system." },
    { q: "Do I need to be home during the service?", a: "For exterior-only cleans, no. For interior work we'll coordinate access. Either way our crew is uniformed, insured, and careful with your home." },
    { q: "Are you licensed and insured?", a: "Yes — BINS Cleaning is fully licensed and insured in Calgary. Best In Neighbourhood Services isn't just our name, it's the standard we're held to." },
  ];
  const [open, setOpen] = useState<number | null>(0);
  return (
    <section id="faq" className="bg-brand-bg py-24 md:py-36">
      <div className="section-container max-w-3xl">
        <div className="text-center">
          <span className="text-xs font-semibold tracking-[0.25em] text-teal uppercase">FAQ</span>
          <h2 className="mt-4 text-4xl md:text-6xl text-white">
            Questions,
            <span className="text-teal"> answered.</span>
          </h2>
        </div>

        <div className="mt-12 flex flex-col gap-4">
          {qs.map((item, i) => {
            const isOpen = open === i;
            return (
              <div
                key={item.q}
                className={`rounded-2xl bg-card border transition-all duration-300 ${isOpen ? "border-teal shadow-[var(--shadow-soft)]" : "border-border"}`}
              >
                <button
                  onClick={() => setOpen(isOpen ? null : i)}
                  className="w-full flex items-center justify-between gap-4 px-6 py-6 text-left"
                >
                  <span className="text-base md:text-lg font-semibold text-white">{item.q}</span>
                  <ChevronDown
                    size={20}
                    className={`shrink-0 text-teal transition-transform duration-300 ${isOpen ? "rotate-180" : ""}`}
                  />
                </button>
                <div
                  className="grid transition-all duration-500 ease-out"
                  style={{ gridTemplateRows: isOpen ? "1fr" : "0fr" }}
                >
                  <div className="overflow-hidden">
                    <p className="px-6 pb-6 text-white/70 font-light leading-relaxed">
                      {item.a}
                    </p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

/* ---------------- Footer ---------------- */
function Footer() {
  return (
    <footer id="contact" className="bg-navy-deep text-white pt-24 pb-10">
      <div className="section-container">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          <div className="lg:col-span-1">
            <div className="flex items-baseline gap-1.5">
              <span className="text-3xl font-extrabold">BINS</span>
              <span className="text-sm font-medium tracking-[0.25em] text-teal-bright">CLEANING</span>
            </div>
            <p className="mt-4 text-sm text-white/60 font-light leading-relaxed">
              Best In Neighbourhood Services. Calgary's premium residential and commercial window
              cleaning company — meticulous, insured, and locally owned.
            </p>
            <div className="mt-6 flex gap-3">
              <a href="#" className="grid h-10 w-10 place-items-center rounded-full border border-white/15 hover:bg-teal hover:border-teal transition">
                <Instagram size={16} />
              </a>
              <a href="#" className="grid h-10 w-10 place-items-center rounded-full border border-white/15 hover:bg-teal hover:border-teal transition">
                <Facebook size={16} />
              </a>
            </div>
          </div>

          <div>
            <h4 className="text-sm font-semibold tracking-[0.2em] text-teal-bright uppercase">Services</h4>
            <ul className="mt-6 space-y-3 text-sm text-white/70 font-light">
              <li className="flex items-center gap-2"><HomeIcon size={14}/> Residential Windows</li>
              <li className="flex items-center gap-2"><Building2 size={14}/> Commercial Windows</li>
              <li className="flex items-center gap-2"><Frame size={14}/> Frames, Tracks & Sills</li>
              <li className="flex items-center gap-2"><Grid3x3 size={14}/> Screen Cleaning</li>
              <li className="flex items-center gap-2"><Droplets size={14}/> Pure-Water High Reach</li>
              <li className="flex items-center gap-2"><CloudRain size={14}/> Gutter Cleaning</li>
              <li className="flex items-center gap-2"><Sun size={14}/> Solar Panel Cleaning</li>
            </ul>
          </div>

          <div>
            <h4 className="text-sm font-semibold tracking-[0.2em] text-teal-bright uppercase">Service Areas</h4>
            <ul className="mt-6 space-y-3 text-sm text-white/70 font-light">
              <li>Calgary NW</li>
              <li>Calgary SW</li>
              <li>Calgary NE & SE</li>
              <li>Airdrie & Cochrane</li>
              <li>Okotoks</li>
              <li>Bearspaw</li>
            </ul>
          </div>

          <div>
            <h4 className="text-sm font-semibold tracking-[0.2em] text-teal-bright uppercase">Contact</h4>
            <ul className="mt-6 space-y-3 text-sm text-white/70 font-light">
              <li className="flex items-center gap-3"><Phone size={16} className="text-teal-bright"/> <a href="tel:+18257603974" className="hover:text-white transition-colors">(825) 760-3974</a></li>
              <li className="flex items-center gap-3"><Mail size={16} className="text-teal-bright"/> <a href="mailto:binsservicesca@gmail.com" className="hover:text-white transition-colors">binsservicesca@gmail.com</a></li>
              <li className="flex items-center gap-3"><MapPin size={16} className="text-teal-bright"/> Calgary, Alberta</li>
              <li className="flex items-center gap-3"><Clock size={16} className="text-teal-bright"/> Mon–Sun 7am–7pm</li>
            </ul>
            <a href="#" className="btn-teal mt-6 text-sm">Book Now <ArrowRight size={16} /></a>
          </div>
        </div>

        <div className="mt-16 pt-8 border-t border-white/10 flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-white/50">
          <span>© {new Date().getFullYear()} BINS Cleaning. All rights reserved.</span>
          <span>Licensed & Insured · Calgary, Alberta</span>
        </div>
      </div>
    </footer>
  );
}

function Home() {
  return (
    <main className="bg-brand-bg relative">
      <div className="scroll-spotlight" aria-hidden="true" />
      <div className="relative">
        <Nav />
        <Hero />
        <TrustStats />
        <Services />
        <WhyUs />
        <Process />
        <FinishedHome />

        <Gallery />
        <Reviews />
        <CTA />
        <FAQ />
        <Footer />
      </div>
    </main>
  );
}

