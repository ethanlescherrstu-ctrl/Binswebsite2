import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { ArrowLeft, ArrowRight, Phone, CheckCircle2, MoveHorizontal, ChevronDown } from "lucide-react";
import { useRef, useState } from "react";

import beforeWindow1 from "@/assets/before.jpg";
import afterWindow1 from "@/assets/after.jpg";
import { interiorSqueegeeBMov as interiorSqueegee } from "@/lib/media";
import { whatsIncludedMov as whatsIncludedVideo } from "@/lib/media";
import { interiorHeroMov as interiorHero } from "@/lib/media";
import { exteriorHeroMov as exteriorHero } from "@/lib/media";
const interiorHeroSrc = interiorHero.url;
const exteriorHeroSrc = exteriorHero.url;

function BeforeAfterSlider({
  before,
  after,
  beforeAlt,
  afterAlt,
}: {
  before: string;
  after: string;
  beforeAlt: string;
  afterAlt: string;
}) {
  const [pos, setPos] = useState(50);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const dragging = useRef(false);

  const updateFromClientX = (clientX: number) => {
    const el = containerRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const pct = ((clientX - rect.left) / rect.width) * 100;
    setPos(Math.max(0, Math.min(100, pct)));
  };

  return (
    <div
      ref={containerRef}
      className="relative w-full aspect-[16/10] overflow-hidden rounded-3xl border border-white/10 shadow-[var(--shadow-card)] select-none touch-none"
      onPointerDown={(e) => {
        dragging.current = true;
        (e.target as Element).setPointerCapture?.(e.pointerId);
        updateFromClientX(e.clientX);
      }}
      onPointerMove={(e) => {
        if (dragging.current) updateFromClientX(e.clientX);
      }}
      onPointerUp={() => (dragging.current = false)}
      onPointerCancel={() => (dragging.current = false)}
    >
      {/* After (full) */}
      <img
        src={after}
        alt={afterAlt}
        loading="lazy"
        width={1600}
        height={1000}
        className="absolute inset-0 h-full w-full object-cover pointer-events-none"
        draggable={false}
      />
      {/* Before (clipped) */}
      <div
        className="absolute inset-0 overflow-hidden pointer-events-none"
        style={{ clipPath: `inset(0 ${100 - pos}% 0 0)` }}
      >
        <img
          src={before}
          alt={beforeAlt}
          loading="lazy"
          width={1600}
          height={1000}
          className="h-full w-full object-cover"
          draggable={false}
        />
      </div>

      {/* Labels */}
      <span className="absolute top-4 left-4 px-3 py-1 rounded-full text-[10px] font-semibold tracking-[0.25em] uppercase bg-black/50 backdrop-blur text-white/90 border border-white/10">
        Before
      </span>
      <span className="absolute top-4 right-4 px-3 py-1 rounded-full text-[10px] font-semibold tracking-[0.25em] uppercase bg-teal-bright/90 text-navy-deep">
        After
      </span>

      {/* Divider + handle */}
      <div
        className="absolute top-0 bottom-0 w-[2px] bg-white shadow-[0_0_20px_rgba(255,255,255,0.5)] pointer-events-none"
        style={{ left: `${pos}%`, transform: "translateX(-1px)" }}
      >
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 h-12 w-12 rounded-full bg-white grid place-items-center shadow-[0_10px_30px_rgba(0,0,0,0.35)]">
          <MoveHorizontal size={20} className="text-navy-deep" />
        </div>
      </div>
    </div>
  );
}

import { extInspectPrepJpg as extInspectPrep } from "@/lib/media";
import { extScrubLoosenJpg as extScrubLoosen } from "@/lib/media";
import { stepLoosenGrimeJpg as stepLoosenGrime } from "@/lib/media";
import { stepDriesSpotFreeJpg as stepDriesSpotFree } from "@/lib/media";
import { extRinseDetailJpg as extRinseDetail } from "@/lib/media";
import { extFinalWalkthroughJpg as extFinalWalkthrough } from "@/lib/media";
import { stepReachPng as stepReach } from "@/lib/media";
import { interiorProtectJpg as interiorProtect } from "@/lib/media";
import { interiorMopSqueegeePng as interiorMop } from "@/lib/media";
import { interiorSillsTracksBJpg as interiorSills } from "@/lib/media";
import { serviceExteriorWindowsPng as svcExterior } from "@/lib/media";
import { serviceInteriorWindowsPng as svcInterior } from "@/lib/media";
import { serviceScreenCleaningPng as svcScreen } from "@/lib/media";
import { serviceSolarPanelPng as svcSolar } from "@/lib/media";
import { serviceCommercialCleaningPng as svcCommercialClean } from "@/lib/media";
import { serviceGutterCleaningPng as svcGutter } from "@/lib/media";
import { glassMirrorGymJpg as glassMirror } from "@/lib/media";
import { glassWineCabinetJpg as glassWine } from "@/lib/media";
import { glassShowerPartitionJpg as glassShower } from "@/lib/media";
import { recentHome1Jpg as gallery1 } from "@/lib/media";
import { recentHome2Jpg as gallery2 } from "@/lib/media";
import { recentHome3Jpg as gallery3 } from "@/lib/media";
import { recentHome4Jpg as gallery4 } from "@/lib/media";
import { recentHome5Jpg as gallery5 } from "@/lib/media";
import { recentHome6Jpg as gallery6 } from "@/lib/media";
import { recentHome7Jpg as gallery7 } from "@/lib/media";
import { recentHome8Jpg as gallery8 } from "@/lib/media";
import { recentHome9Jpg as gallery9 } from "@/lib/media";
import { recentHome10Jpg as gallery10 } from "@/lib/media";
import { recentHome11Jpg as gallery11 } from "@/lib/media";
type Service = {
  slug: string;
  eyebrow: string;
  heroLead: string;
  heroAccent: string;
  subhead: string;
  image: string;
  processTitle: string;
  processTitleAccent: string;
  processIntro: string;
  steps: { label: string; title: string; desc: string; img: string }[];
};

const SERVICES: Record<string, Service> = {
  "exterior-window-cleaning": {
    slug: "exterior-window-cleaning",
    eyebrow: "Exterior Window Cleaning",
    heroLead: "Glass so clear,",
    heroAccent: "it disappears.",
    subhead:
      "Calgary grime, pollen and hard-water spots — gone. Streak-free glass on every exterior pane.",
    image: svcExterior.url,
    processTitle: "Perfect windows start with a",
    processTitleAccent: "perfected process.",
    processIntro:
      "Every Calgary home gets the same proven routine: reach, scrub, then rinse with pure water. Scroll on to watch a clean unfold, step by step.",
    steps: [
      {
        label: "Reach",
        title: "Every storey, from the ground",
        desc: "Carbon-fibre water-fed poles reach second- and third-storey glass safely — no ladders leaning on your home.",
        img: stepReach.url,
      },
      {
        label: "Scrub",
        title: "Loosen the grime",
        desc: "A soft brush head agitates pollen, dust and hard-water spray across the whole pane and frame.",
        img: stepLoosenGrime.url,
      },
      {
        label: "Rinse Pure",
        title: "Dries spot-free",
        desc: "A pure-water rinse leaves zero minerals behind, so the glass dries crystal-clear — no streaks.",
        img: stepDriesSpotFree.url,

      },
    ],
  },
  "interior-window-cleaning": {
    slug: "interior-window-cleaning",
    eyebrow: "Interior Window Cleaning · Calgary",
    heroLead: "Rooms brighter,",
    heroAccent: "the view restored.",
    subhead:
      "Shoe covers on, sills and tracks detailed, light pouring back into every room of your home.",
    image: svcInterior.url,
    processTitle: "A clean you can feel —",
    processTitleAccent: "hand-finished.",
    processIntro:
      "Every interior pane is mopped, squeegeed and buffed by hand, then sills and tracks are detailed so nothing dulls the finish.",
    steps: [
      {
        label: "Protect",
        title: "Your home comes first",
        desc: "Shoe covers on, drop cloths down and blinds gently moved — furniture and floors stay untouched.",
        img: interiorProtect.url,
      },
      {
        label: "Hand-Wash",
        title: "Mop and squeegee",
        desc: "Each pane is washed with a professional mop, then pulled streak-free by a hand-held squeegee.",
        img: interiorMop.url,
      },
      {
        label: "Detail",
        title: "Sills and tracks",
        desc: "Dust, dead bugs and grime lifted from every sill, track and corner — the whole window looks new.",
        img: interiorSills.url,
      },
    ],
  },
  "screen-cleaning": {
    slug: "screen-cleaning",
    eyebrow: "Screen Cleaning",
    heroLead: "Airflow restored,",
    heroAccent: "views wide open.",
    subhead:
      "Screens removed, hand-washed, dried and re-fitted so pollen, dust and grime no longer choke your windows — for fresher, clearer home airflow after screen cleaning.",
    image: svcScreen.url,
    processTitle: "Clean screens are —",
    processTitleAccent: "clear views.",
    processIntro:
      "Every screen gets the same careful routine off the window so no debris drifts back onto freshly cleaned glass.",
    steps: [
      {
        label: "Remove",
        title: "Off the frame",
        desc: "Each screen is labelled and carefully lifted out so it goes back into the exact opening it came from.",
        img: svcScreen.url,
      },
      {
        label: "Wash",
        title: "Hand-scrubbed both sides",
        desc: "A soft brush and gentle soap lift pollen, dust and cobwebs from mesh and frame — no torn screens.",
        img: svcExterior.url,
      },
      {
        label: "Refit",
        title: "Dried and reinstalled",
        desc: "Screens are fully dried, checked for damage and re-seated so airflow and views stay fresh all season.",
        img: svcInterior.url,
      },
    ],
  },
  "commercial-cleaning": {
    slug: "commercial-cleaning",
    eyebrow: "Commercial Cleaning",
    heroLead: "Storefronts that,",
    heroAccent: "sell at a glance.",
    subhead:
      "Storefronts, dealerships, offices and strata — streak-free glass, after-hours scheduling, fully insured crews.",
    image: svcCommercialClean.url,
    processTitle: "Business-ready glass —",
    processTitleAccent: "on your schedule.",
    processIntro:
      "We work around your hours with uniformed, insured crews so your customers only see the result: crystal-clear glass.",
    steps: [
      {
        label: "Schedule",
        title: "After-hours or off-peak",
        desc: "Weekly, monthly or quarterly visits scheduled around your business — no disruption to staff or customers.",
        img: svcCommercialClean.url,
      },
      {
        label: "Clean",
        title: "Storefronts and interiors",
        desc: "Entrances, display glass, partitions and mirrors cleaned to a professional, streak-free finish.",
        img: svcExterior.url,
      },
      {
        label: "Report",
        title: "Documented and insured",
        desc: "$2M liability coverage, WCB certified, with visit reports so every property manager stays in the loop.",
        img: svcInterior.url,
      },
    ],
  },
  "solar-panel-cleaning": {
    slug: "solar-panel-cleaning",
    eyebrow: "Solar Panel Cleaning",
    heroLead: "More sun in,",
    heroAccent: "more power out.",
    subhead:
      "Dust, pollen and film cut solar output. A safe, residue-free purified-water clean restores efficiency.",
    image: svcSolar.url,
    processTitle: "Cleaner panels —",
    processTitleAccent: "measurable output.",
    processIntro:
      "Panels are cleaned from the ground with soft brushes and pure water — no scratched glass, no roof risk, no residue.",
    steps: [
      {
        label: "Inspect",
        title: "Panel and roof safety",
        desc: "We assess panel type, tilt and roof condition before touching a single array so nothing is damaged.",
        img: svcSolar.url,
      },
      {
        label: "Soft-Brush",
        title: "Lift dust and pollen",
        desc: "Soft, panel-safe brushes on carbon-fibre poles agitate grime without scratching the tempered glass.",
        img: svcExterior.url,
      },
      {
        label: "Pure-Rinse",
        title: "Zero-residue finish",
        desc: "A pure-water rinse dries clear — no minerals or soap film left behind to shade the cells.",
        img: svcInterior.url,
      },
    ],
  },
  "gutter-cleaning": {
    slug: "gutter-cleaning",
    eyebrow: "Gutter Cleaning",
    heroLead: "Water flowing,",
    heroAccent: "home protected.",
    subhead:
      "Debris flushed, downspouts cleared and flow restored — protecting your roof, siding and foundation.",
    image: svcGutter.url,
    processTitle: "Clear gutters —",
    processTitleAccent: "a dry foundation.",
    processIntro:
      "Every visit follows the same three steps so water goes where it should — away from your home, not into it.",
    steps: [
      {
        label: "Clear",
        title: "Debris by hand",
        desc: "Leaves, needles and shingle grit are removed from every run by hand — no clogs left behind.",
        img: svcGutter.url,
      },
      {
        label: "Flush",
        title: "Downspouts tested",
        desc: "Each downspout is flushed with water to confirm free flow from roof to grade.",
        img: svcExterior.url,
      },
      {
        label: "Inspect",
        title: "Report and photos",
        desc: "We flag loose hangers, separations or damaged sections with photos so nothing is missed.",
        img: svcInterior.url,
      },
    ],
  },
};

export const Route = createFileRoute("/services/$slug")({
  loader: ({ params }) => {
    const service = SERVICES[params.slug];
    if (!service) throw notFound();
    return { service };
  },
  head: ({ loaderData }) => {
    if (!loaderData) {
      return {
        meta: [
          { title: "Service not found — BINS Cleaning" },
          { name: "robots", content: "noindex" },
        ],
      };
    }
    const s = loaderData.service;
    const title = `${s.eyebrow} in Calgary — BINS Cleaning`;
    const desc = s.subhead;
    return {
      meta: [
        { title },
        { name: "description", content: desc },
        { property: "og:title", content: title },
        { property: "og:description", content: desc },
        { property: "og:image", content: s.image },
        { name: "twitter:card", content: "summary_large_image" },
        { name: "twitter:image", content: s.image },
      ],
    };
  },
  component: ServiceDetail,
  notFoundComponent: () => (
    <div className="min-h-screen grid place-items-center bg-brand-bg text-white">
      <div className="text-center">
        <h1 className="text-3xl font-bold">Service not found</h1>
        <Link to="/" className="mt-6 inline-block text-teal-bright underline">
          Back to home
        </Link>
      </div>
    </div>
  ),
  errorComponent: () => (
    <div className="min-h-screen grid place-items-center bg-brand-bg text-white">
      <div className="text-center">
        <h1 className="text-3xl font-bold">Something went wrong</h1>
        <Link to="/" className="mt-6 inline-block text-teal-bright underline">
          Back to home
        </Link>
      </div>
    </div>
  ),
});

function ServiceDetail() {
  const { service } = Route.useLoaderData();

  return (
    <main className="bg-brand-bg text-white relative">
      <div className="scroll-spotlight" aria-hidden="true" />
      <div className="relative">
      {/* Simple top bar */}
      <header className="absolute inset-x-0 top-0 z-30">
        <div className="section-container flex h-20 items-center justify-between">
          <Link to="/" className="flex items-baseline gap-1.5 text-white">
            <span className="text-2xl font-extrabold tracking-tight leading-none">BINS</span>
            <span className="text-xs font-medium tracking-[0.25em] text-teal">CLEANING</span>
          </Link>
          <Link
            to="/"
            className="inline-flex items-center gap-2 text-sm text-white/80 hover:text-white transition"
          >
            <ArrowLeft size={16} /> Back to home
          </Link>
        </div>
      </header>

      {/* Hero */}
      <section className="relative min-h-[92vh] w-full overflow-hidden">
        {service.slug === "interior-window-cleaning" || service.slug === "exterior-window-cleaning" ? (
          <video
            src={service.slug === "interior-window-cleaning" ? interiorHeroSrc : exteriorHeroSrc}
            poster={service.image}
            autoPlay
            loop
            muted
            playsInline
            preload="auto"
            className="absolute inset-0 h-full w-full object-cover"
          />
        ) : (
          <img
            src={service.image}
            alt={service.eyebrow}
            className="absolute inset-0 h-full w-full object-cover"
          />
        )}
        <div className="absolute inset-0 bg-gradient-to-r from-navy-deep/90 via-navy-deep/60 to-navy-deep/20" />
        <div className="absolute inset-0 bg-navy-deep/30" />

        <div className="relative z-10 section-container flex min-h-[92vh] flex-col items-start justify-center pt-24 pb-20 md:pl-[6%]">
          <div className="text-xs font-semibold tracking-[0.25em] text-teal-bright uppercase">
            {service.eyebrow}
          </div>

          <h1 className="mt-8 max-w-3xl text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-extrabold leading-[1.05]">
            {service.heroLead}
            <br />
            <span className="text-teal-bright">{service.heroAccent}</span>
          </h1>

          <p className="mt-8 max-w-xl text-lg md:text-xl text-white/80 font-light leading-relaxed">
            {service.subhead}
          </p>

          <div className="mt-10 flex flex-wrap items-center gap-4">
            <Link to="/" hash="contact" className="btn-teal text-sm px-6 py-3">
              Get a Free Quote <ArrowRight size={16} />
            </Link>
            <a
              href="tel:+18257603974"
              className="inline-flex items-center gap-2 rounded-full border border-white/25 bg-white/5 px-6 py-3 text-sm font-medium text-white backdrop-blur hover:bg-white/10 transition"
            >
              <Phone size={16} /> Call (825) 760-3974
            </a>
          </div>
        </div>
      </section>

      {/* Step-by-step horizontal walkthrough */}
      {service.slug === "exterior-window-cleaning" && (
        <section className="bg-brand-bg py-24 md:py-32">
          <div className="section-container">
            <div className="max-w-3xl mx-auto text-center">
              <span className="text-xs font-semibold tracking-[0.25em] text-teal-bright uppercase">
                The Proven Path
              </span>
              <h2 className="mt-6 text-4xl md:text-6xl font-extrabold leading-[1.05]">
                The proven path{" "}
                <span className="text-teal-bright">to perfect glass</span>
              </h2>
              <p className="mt-6 text-base md:text-lg text-white/70 font-light leading-relaxed">
                Four repeatable steps we follow on every Calgary home — from the first knock to the final walkthrough.
              </p>
            </div>

            <div className="mt-16 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-4 max-w-7xl mx-auto items-stretch">
              {[
                {
                  title: "Inspect & Prep",
                  desc: "We assess every window, protect the surrounding area and choose the right approach for your glass.",
                  img: extInspectPrep.url,
                },
                {
                  title: "Scrub & Loosen",
                  desc: "A professional solution breaks down pollen, dust and hard-water buildup across each pane.",
                  img: extScrubLoosen.url,

                },
                {
                  title: "Rinse & Detail",
                  desc: "A purified-water rinse leaves zero streaks and zero residue, plus hand-done frame detailing on every window.",
                  img: extRinseDetail.url,
                },
                {
                  title: "Final Walkthrough",
                  desc: "We inspect with you. Not perfect? We re-do it on the spot — guaranteed.",
                  img: extFinalWalkthrough.url,
                },
              ].map((step, i, arr) => (
                <div key={step.title} className="relative flex">
                  <article className="flex flex-col w-full rounded-2xl bg-[oklch(0.18_0.03_240)] border border-white/5 shadow-[var(--shadow-card)] overflow-hidden">
                    <div className="aspect-[4/3] overflow-hidden">
                      <img
                        src={step.img}
                        alt={step.title}
                        className="h-full w-full object-cover"
                        loading="lazy"
                      />
                    </div>
                    <div className="p-6 flex flex-col flex-1">
                      <div className="grid h-11 w-11 place-items-center rounded-xl bg-gradient-to-br from-teal-bright to-teal text-white font-bold shadow-lg">
                        {i + 1}
                      </div>
                      <h3 className="mt-5 text-xl md:text-2xl font-bold">{step.title}</h3>
                      <p className="mt-3 text-sm md:text-base text-white/70 font-light leading-relaxed">
                        {step.desc}
                      </p>
                    </div>
                  </article>
                  {i < arr.length - 1 && (
                    <div className="hidden lg:flex absolute top-1/2 -right-3 -translate-y-1/2 z-10 h-6 w-6 items-center justify-center">
                      <ArrowRight size={20} className="text-teal-bright" />
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* What's Included */}
      {service.slug === "exterior-window-cleaning" && (
        <section className="bg-brand-bg py-24 md:py-32">
          <div className="section-container">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center max-w-7xl mx-auto">
              <div className="rounded-2xl overflow-hidden shadow-[var(--shadow-card)] border border-white/5 bg-black aspect-[4/4.4]">
                <video
                  src={whatsIncludedVideo.url}
                  autoPlay
                  muted
                  loop
                  playsInline
                  preload="metadata"
                  className="h-full w-full object-cover"
                />
              </div>
              <div>
                <span className="text-xs font-semibold tracking-[0.25em] text-teal-bright uppercase">
                  What's Included
                </span>
                <h2 className="mt-6 text-4xl md:text-5xl lg:text-6xl font-extrabold leading-[1.05]">
                  Every pane, frame <span className="text-teal-bright">& sill</span>
                </h2>
                <p className="mt-6 text-base md:text-lg text-white/70 font-light leading-relaxed">
                  We don't cut corners — literally. Our exterior service covers it all:
                </p>

                <ul className="mt-10 grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-6">
                  {[
                    { bold: "All exterior glass", rest: "hand-cleaned & squeegeed" },
                    { bold: "Purified water", rest: "for spot-free drying" },
                    { bold: "Frames & sills", rest: "wiped down" },
                    { bold: "Hard-water & mineral", rest: "spot removal" },
                    { bold: "Ground & high-reach", rest: "windows" },
                    { bold: "100% satisfaction", rest: "guarantee" },
                  ].map((item) => (
                    <li key={item.bold} className="flex items-start gap-3">
                      <span className="mt-0.5 grid h-6 w-6 shrink-0 place-items-center rounded-full bg-teal-bright text-navy-deep">
                        <CheckCircle2 size={14} strokeWidth={3} />
                      </span>
                      <p className="text-white/85 font-light leading-relaxed">
                        <span className="font-semibold text-white">{item.bold}</span>{" "}
                        {item.rest}
                      </p>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </section>
      )}


      {/* Interior intro w/ video */}
      {service.slug === "interior-window-cleaning" && (
        <section className="relative bg-brand-bg py-24 md:py-32 overflow-hidden">
          <div className="section-container">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
              <div>
                <h2 className="text-5xl md:text-6xl lg:text-7xl font-extrabold leading-[1.02]">
                  A Clear View Makes <span className="text-teal-bright">A Clear Mind</span>
                </h2>
                <p className="mt-8 max-w-xl text-lg md:text-xl text-white/75 font-light leading-relaxed">
                  Streak-free glass inside, detailed sills and tracks — a brighter home in every room.
                </p>
              </div>

              <div className="relative">
                <div className="relative mx-auto w-full max-w-[520px] rounded-3xl overflow-hidden border border-teal-bright/30 shadow-[var(--shadow-card)] aspect-[4/3.6] lg:aspect-[4/4.2] bg-black">
                  <video
                    src={interiorSqueegee.url}
                    autoPlay
                    muted
                    loop
                    playsInline
                    preload="metadata"
                    className="absolute inset-0 h-full w-full object-cover"
                  />
                  <div className="absolute bottom-4 left-4 inline-flex items-center gap-2 rounded-full bg-teal-bright/95 text-navy-deep px-4 py-2 text-xs font-semibold shadow-lg">
                    <span className="h-2 w-2 rounded-full bg-navy-deep" />
                    The squeegee finish, up close
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Process */}



      <section className="relative bg-brand-bg py-24 md:py-36">
        <div className="section-container">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-4xl md:text-6xl font-extrabold leading-[1.05]">
              {service.processTitle}{" "}
              <span className="text-teal-bright">{service.processTitleAccent}</span>
            </h2>
            <p className="mt-6 text-base md:text-lg text-white/70 font-light leading-relaxed">
              {service.processIntro}
            </p>
            <div className="mx-auto mt-10 h-16 w-px bg-gradient-to-b from-teal-bright/80 to-transparent" />
          </div>

          <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8 max-w-6xl mx-auto">
            {service.steps.map((step: Service["steps"][number], i: number) => (
              <article
                key={step.label}
                className="rounded-2xl bg-[oklch(0.18_0.03_240)] overflow-hidden shadow-[var(--shadow-card)] border border-white/5"
              >
                <div className="aspect-[4/3] overflow-hidden">
                  <img
                    src={step.img}
                    alt={step.title}
                    className="h-full w-full object-cover"
                    loading="lazy"
                  />
                </div>
                <div className="p-7">
                  <div className="flex items-center gap-3">
                    <span className="grid h-8 w-8 place-items-center rounded-full bg-teal-bright text-navy-deep font-bold text-sm">
                      {i + 1}
                    </span>
                    <span className="text-xs font-semibold tracking-[0.25em] text-teal-bright uppercase">
                      {step.label}
                    </span>
                  </div>
                  <h3 className="mt-5 text-xl md:text-2xl font-bold">{step.title}</h3>
                  <p className="mt-3 text-white/70 font-light leading-relaxed">{step.desc}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* Screens: What's Included */}
      {service.slug === "screen-cleaning" && (
        <section className="bg-brand-bg py-24 md:py-32">
          <div className="section-container">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center max-w-6xl mx-auto">
              <div className="rounded-2xl overflow-hidden shadow-[var(--shadow-card)]">
                <img
                  src={svcScreen.url}
                  alt="BINS technician removing and hand-washing window screens at a Calgary home"
                  className="w-full h-full object-cover"
                  loading="lazy"
                />
              </div>
              <div>
                <span className="text-xs font-semibold tracking-[0.25em] text-teal-bright uppercase">
                  What's Included
                </span>
                <h2 className="mt-6 text-4xl md:text-6xl font-extrabold leading-[1.05]">
                  Off, washed, <span className="text-teal-bright">and back on</span>
                </h2>
                <p className="mt-6 text-base md:text-lg text-white/70 font-light leading-relaxed">
                  A small detail that makes a big difference.
                </p>
                <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-5">
                  {[
                    { b: "Careful removal", r: "of every screen" },
                    { b: "Hand-washed", r: "mesh & frames" },
                    { b: "Dust & pollen", r: "rinsed away" },
                    { b: "Fully dried", r: "before re-fitting" },
                    { b: "Re-installed", r: "exactly where they belong" },
                    { b: "100% satisfaction", r: "guarantee" },
                  ].map((item) => (
                    <div key={item.b} className="flex items-start gap-3">
                      <span className="mt-1 grid h-6 w-6 flex-none place-items-center rounded-full bg-gradient-to-br from-teal-bright to-teal text-white shadow-lg">
                        <CheckCircle2 size={14} strokeWidth={3} />
                      </span>
                      <p className="text-base text-white/85 font-light leading-relaxed">
                        <strong className="text-white font-semibold">{item.b}</strong> {item.r}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Filtration / Pure-Clean System */}
      {service.slug !== "screen-cleaning" && (
      <section className="bg-brand-bg py-24 md:py-32">

        <div className="section-container">
          <div className="max-w-3xl mx-auto text-center">
            <span className="text-xs font-semibold tracking-[0.25em] text-teal-bright uppercase">
              {service.slug === "interior-window-cleaning"
                ? "The Craft of Streak-Free Interiors"
                : service.slug === "gutter-cleaning"
                  ? "More Than Gutter Cleaning"
                  : service.slug === "solar-panel-cleaning"
                    ? "The Secret Behind Maximum Solar Performance"
                    : "The Science of Spot-Free"}
            </span>
            <h2 className="mt-6 text-4xl md:text-6xl font-extrabold leading-[1.05]">
              {service.slug === "interior-window-cleaning" ? (
                <>
                  The Secret Behind{" "}
                  <span className="text-teal-bright">Streak-Free Interiors</span>
                </>
              ) : service.slug === "gutter-cleaning" ? (
                <>
                  Protecting Your Home,{" "}
                  <span className="text-teal-bright">Inside and Out</span>
                </>
              ) : service.slug === "solar-panel-cleaning" ? (
                <>
                  The Secret Behind{" "}
                  <span className="text-teal-bright">Maximum Solar Performance</span>
                </>
              ) : (
                <>
                  The Secret Behind{" "}
                  <span className="text-teal-bright">Spot-Free Windows</span>
                </>
              )}
            </h2>
            {service.slug === "interior-window-cleaning" ? (
              <>
                <p className="mt-6 text-base md:text-lg text-white/70 font-light leading-relaxed">
                  Our interior process begins long before the glass is cleaned. Every frame, sill,
                  and track is meticulously detailed by hand to remove the dust, debris, and hidden
                  buildup that can continually settle back onto freshly cleaned glass before each
                  pane is finished with professional mops, squeegees, and premium microfiber cloths
                  for a flawless, streak-free finish.
                </p>
                <p className="mt-4 text-base md:text-lg text-white/70 font-light leading-relaxed">
                  This comprehensive approach helps your windows stay cleaner for longer while
                  preserving the beauty, clarity, and lasting appearance of one of your home's most
                  valuable features. It's this meticulous attention to detail that defines the{" "}
                  <strong className="text-white">BINS Clear Window Process™</strong> — trusted by
                  over 500 Calgary homeowners who value exceptional craftsmanship and lasting
                  results.
                </p>
              </>
            ) : service.slug === "gutter-cleaning" ? (
              <>
                <p className="mt-6 text-base md:text-lg text-white/70 font-light leading-relaxed">
                  A properly maintained gutter system does more than improve curb appeal — it helps
                  protect your home's roof, fascia, foundation, and landscaping from costly water
                  damage. That's why every BINS gutter service combines professional pressure
                  flushing with meticulous hand detailing to restore both the inside and outside of
                  every gutter.
                </p>
                <p className="mt-4 text-base md:text-lg text-white/70 font-light leading-relaxed">
                  By removing built-up debris, flushing the entire drainage system, and carefully
                  detailing every visible surface, we restore proper water flow while leaving your
                  gutters looking as clean as they function. It's the{" "}
                  <strong className="text-white">BINS Gutter Restore Process™</strong> — crafted
                  for homeowners who believe every detail matters.
                </p>
              </>
            ) : service.slug === "solar-panel-cleaning" ? (
              <>
                <p className="mt-6 text-base md:text-lg text-white/70 font-light leading-relaxed">
                  Solar panels are constantly exposed to dust, pollen, bird droppings, and airborne
                  contaminants that reduce the amount of sunlight reaching the solar cells. That's
                  why every panel is cleaned using the{" "}
                  <strong className="text-white">BINS Pure-Clean System™</strong> — our premium
                  4-stage Reverse Osmosis & Deionization filtration system that purifies water to 0
                  Total Dissolved Solids (0 TDS).
                </p>
                <p className="mt-4 text-base md:text-lg text-white/70 font-light leading-relaxed">
                  This ultra-pure water safely lifts away dirt and contaminants before drying
                  naturally without leaving behind mineral deposits, soap residue, or streaks. The
                  result is cleaner panels that capture more sunlight, operate more efficiently,
                  and maintain their appearance without introducing residue that can attract dirt
                  back to the surface.
                </p>
              </>
            ) : (
              <>
                <p className="mt-6 text-base md:text-lg text-white/70 font-light leading-relaxed">
                  Calgary's hard water contains minerals that leave behind spots, streaks, and
                  residue on glass. That's why every exterior window is cleaned using the{" "}
                  <strong className="text-white">BINS Pure-Clean System™</strong> — our premium
                  4-stage Reverse Osmosis & Deionization filtration system that purifies water to 0
                  Total Dissolved Solids (0 TDS).
                </p>
                <p className="mt-4 text-base md:text-lg text-white/70 font-light leading-relaxed">
                  This ultra-pure water lifts away dirt and dries naturally without leaving behind
                  mineral spots, soap residue, or streaks — keeping your windows crystal clear for
                  up to <strong className="text-white">six times longer</strong> than traditional
                  cleaning.
                </p>
              </>
            )}

          </div>

          <div className="mt-16 grid grid-cols-1 md:grid-cols-4 gap-6 max-w-6xl mx-auto items-stretch">
            {(service.slug === "interior-window-cleaning"
              ? [
                  {
                    title: "Detail Frames & Sills",
                    desc: "Every frame and sill is hand-wiped to lift dust and buildup that would otherwise resettle on clean glass.",
                  },
                  {
                    title: "Vacuum the Tracks",
                    desc: "Tracks are vacuumed and detailed by hand — removing hidden grit most cleaners leave behind.",
                  },
                  {
                    title: "Mop & Squeegee",
                    desc: "Professional mops loosen film, then a sharp squeegee pull clears each pane in a single, clean stroke.",
                  },
                  {
                    title: "Microfiber Finish",
                    desc: "Premium microfiber cloths detail the edges for a flawless, streak-free finish on every window.",
                  },
                ]
              : service.slug === "gutter-cleaning"
              ? [
                  {
                    title: "Hand-Clear Debris",
                    desc: "Leaves, twigs, and built-up sludge are removed by hand from every section — no shortcuts, no leftover mess.",
                  },
                  {
                    title: "Pressure Flush",
                    desc: "The entire gutter and downspout system is flushed under pressure to clear hidden blockages and restore proper flow.",
                  },
                  {
                    title: "Detail Exteriors",
                    desc: "The outside face of every gutter is hand-detailed to lift streaks, tiger stripes, and grime for a clean finish.",
                  },
                  {
                    title: "Flow Test & Inspect",
                    desc: "We test drainage end-to-end and flag any loose brackets or trouble spots — so nothing surprises you later.",
                  },
                ]
              : service.slug === "solar-panel-cleaning"
              ? [
                  {
                    title: "Sediment Filtration",
                    desc: "Removes sand, dirt, and other abrasive particles to protect both the filtration system and your solar panels throughout the cleaning process.",
                  },
                  {
                    title: "Carbon Filtration",
                    desc: "Activated carbon removes chlorine and organic contaminants that could leave residue on the panel surface before reverse osmosis purification.",
                  },
                  {
                    title: "Reverse Osmosis",
                    desc: "A high-performance membrane removes virtually all dissolved minerals from Calgary's hard water, producing ultra-pure water that safely rinses panels without spotting.",
                  },
                  {
                    title: "Deionization",
                    desc: "The final polishing stage removes any remaining trace minerals, delivering 0 TDS ultra-pure water that dries naturally and leaves your solar panels completely residue-free.",
                  },
                ]
              : [
                  {
                    title: "Sediment Filter",
                    desc: "Traps dirt, sand and rust so nothing abrasive ever reaches the finer stages.",
                  },
                  {
                    title: "Carbon Filter",
                    desc: "Activated carbon pulls out chlorine and organics that would otherwise streak the glass.",
                  },
                  {
                    title: "Reverse Osmosis",
                    desc: "A fine membrane rejects roughly 98% of dissolved minerals (TDS) — the stuff that spots glass.",
                  },
                  {
                    title: "Deionization",
                    desc: "A final DI resin polish drops the water down to 0 TDS — scientifically pure.",
                  },
                ]

            ).map((stage, i, arr) => (
              <div key={stage.title} className="relative">
                <div className="h-full rounded-2xl bg-[oklch(0.16_0.03_240)] border border-white/5 p-7 text-center shadow-[var(--shadow-card)]">
                  <div className="mx-auto grid h-11 w-11 place-items-center rounded-full bg-gradient-to-br from-teal-bright to-teal text-white font-bold shadow-lg">
                    {i + 1}
                  </div>
                  <h3 className="mt-6 text-lg md:text-xl font-bold">{stage.title}</h3>
                  <p className="mt-3 text-sm text-white/70 font-light leading-relaxed">
                    {stage.desc}
                  </p>
                </div>
                {i < arr.length - 1 && (
                  <div className="hidden md:flex absolute top-1/2 -right-3 -translate-y-1/2 z-10 h-6 w-6 items-center justify-center">
                    <ArrowRight size={20} className="text-teal-bright" />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>
      )}

      {/* Glass Surfaces & Mirrors — interior only */}
      {service.slug === "interior-window-cleaning" && (
        <section className="bg-brand-bg py-24 md:py-32 border-t border-white/5">
          <div className="section-container">
            <div className="max-w-3xl mx-auto text-center">
              <span className="text-xs font-semibold tracking-[0.25em] text-teal-bright uppercase">
                Glass Surfaces & Mirrors
              </span>
              <h2 className="mt-6 text-4xl md:text-6xl font-extrabold leading-[1.05]">
                Crystal-clear glass{" "}
                <span className="text-teal-bright">throughout your home or business</span>
              </h2>
              <p className="mt-6 text-base md:text-lg text-white/70 font-light leading-relaxed">
                We don't just clean interior windows. Our service also includes glass cabinet doors,
                display cases, gym mirrors, wall mirrors, glass partitions, shower glass, and other
                interior glass surfaces. We remove fingerprints, dust, smudges, and streaks —
                leaving every glass surface sparkling clean and crystal clear.
              </p>
            </div>

            <div className="mt-14 grid grid-cols-1 md:grid-cols-3 gap-6 max-w-6xl mx-auto">
              {[
                { src: glassMirror.url, alt: "Gym and wall mirrors cleaned by BINS", label: "Gym & Wall Mirrors" },
                { src: glassWine.url, alt: "Glass wine cabinet cleaned by BINS", label: "Glass Cabinets & Display Cases" },
                { src: glassShower.url, alt: "Shower glass and partitions cleaned by BINS", label: "Shower Glass & Partitions" },
              ].map((p) => (
                <figure key={p.label} className="relative overflow-hidden rounded-2xl border border-white/5 shadow-[var(--shadow-card)]">
                  <div className="aspect-[4/3] overflow-hidden">
                    <img src={p.src} alt={p.alt} loading="lazy" className="h-full w-full object-cover" />
                  </div>
                  <figcaption className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-4 text-sm font-semibold text-white">
                    {p.label}
                  </figcaption>
                </figure>
              ))}
            </div>
          </div>
        </section>
      )}



      {/* Why Professional Solar Panel Cleaning Matters */}
      {service.slug === "solar-panel-cleaning" && (
        <section className="bg-brand-bg py-24 md:py-32 border-t border-white/5">
          <div className="section-container">
            <div className="max-w-3xl mx-auto text-center">
              <span className="text-xs font-semibold tracking-[0.25em] text-teal-bright uppercase">
                Why It Matters
              </span>
              <h2 className="mt-6 text-4xl md:text-6xl font-extrabold leading-[1.05]">
                Why Professional{" "}
                <span className="text-teal-bright">Solar Panel Cleaning</span> Matters
              </h2>
              <p className="mt-6 text-base md:text-lg text-white/70 font-light leading-relaxed">
                Even a thin layer of dust, pollen, or environmental buildup can reduce the amount
                of sunlight reaching your solar panels. Regular professional cleaning helps
                restore maximum light transmission, allowing your system to operate closer to its
                designed efficiency while maintaining the long-term appearance of your investment.
              </p>
              <p className="mt-4 text-base md:text-lg text-white/70 font-light leading-relaxed">
                Unlike tap water, the{" "}
                <strong className="text-white">BINS Pure-Clean System™</strong> leaves behind no
                mineral deposits or hard water spotting, ensuring every panel dries naturally
                clean without chemicals, detergents, or abrasive scrubbing.
              </p>
            </div>
          </div>
        </section>
      )}





      {/* Before / After */}
      {service.slug === "exterior-window-cleaning" && (
        <section className="bg-brand-bg py-24 md:py-32">
          <div className="section-container">
            <div className="max-w-3xl mx-auto text-center">
              <span className="text-xs font-semibold tracking-[0.25em] text-teal-bright uppercase">
                Before & After
              </span>
              <h2 className="mt-6 text-4xl md:text-6xl font-extrabold leading-[1.05]">
                See the{" "}
                <span className="text-teal-bright">difference</span> for yourself
              </h2>
              <p className="mt-6 text-base md:text-lg text-white/70 font-light leading-relaxed">
                Drag the slider to reveal the transformation — from Calgary grime and hard-water spots to
                crystal-clear glass finished with the BINS Pure-Clean System™.
              </p>
            </div>

            <div className="mt-14 max-w-5xl mx-auto">
              <BeforeAfterSlider
                before={beforeWindow1}
                after={afterWindow1}
                beforeAlt="Dirty exterior window before BINS cleaning"
                afterAlt="Crystal-clear exterior window after BINS cleaning"
              />
              <p className="mt-4 text-center text-sm text-white/50 font-light">
                Drag the handle left and right to compare.
              </p>
            </div>
          </div>
        </section>
      )}






      {/* Recent Work Gallery */}
      {(service.slug === "exterior-window-cleaning" || service.slug === "interior-window-cleaning") && (
        <section className="bg-brand-bg py-24 md:py-32">
          <div>
            <div className="max-w-3xl mx-auto text-center px-4">
              <span className="text-xs font-semibold tracking-[0.25em] text-teal-bright uppercase">
                Our Recent Work
              </span>
              <h2 className="mt-6 text-4xl md:text-6xl font-extrabold leading-[1.05] text-white">
                Bringing out the best in{" "}
                <span className="text-teal-bright">Calgary homes</span>
              </h2>
              <p className="mt-6 text-base md:text-lg text-white/70 font-light leading-relaxed">
                A look at recent {service.slug === "interior-window-cleaning" ? "interior" : "exterior"} window cleans across the city — every pane finished with the BINS {service.slug === "interior-window-cleaning" ? "Clear Window Process™" : "Pure-Clean System™"}.
              </p>
            </div>

            <div className="relative mt-16 px-1 sm:px-2">
              <div
                className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2 md:gap-3"
                style={{
                  WebkitMaskImage:
                    "linear-gradient(to right, transparent 0, rgba(0,0,0,0.35) 1.5%, #000 5%, #000 95%, rgba(0,0,0,0.35) 98.5%, transparent 100%)",
                  maskImage:
                    "linear-gradient(to right, transparent 0, rgba(0,0,0,0.35) 1.5%, #000 5%, #000 95%, rgba(0,0,0,0.35) 98.5%, transparent 100%)",
                }}
              >
                {[
                  { src: gallery1.url, alt: "Calgary two-story home with freshly cleaned windows" },
                  { src: gallery2.url, alt: "Calgary backyard windows spotless after cleaning" },
                  { src: gallery3.url, alt: "Calgary home front with streak-free windows" },
                  { src: gallery6.url, alt: "Calgary luxury home back exterior with spotless windows at sunset" },
                  { src: gallery5.url, alt: "Calgary two-story home front with freshly cleaned windows at dusk" },
                  { src: gallery4.url, alt: "Calgary bungalow with sparkling clean windows" },
                  { src: gallery7.url, alt: "Calgary bi-level home with newly cleaned windows on a summer evening" },
                  { src: gallery8.url, alt: "Calgary two-storey home side profile with clean windows" },
                  { src: gallery9.url, alt: "Calgary home exterior detail after window clean" },
                  { src: gallery10.url, alt: "Calgary home exterior with freshly cleaned windows after BINS" },
                  { src: gallery11.url, alt: "Calgary bungalow front exterior with spotless windows after cleaning" },
                ].map((img, i) => (
                  <div
                    key={i}
                    className="group relative overflow-hidden rounded-2xl border border-white/5 shadow-[var(--shadow-card)] aspect-[4/3]"
                  >
                    <img
                      src={img.src}
                      alt={img.alt}
                      loading="lazy"
                      className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                  </div>
                ))}
              </div>
              <div className="pointer-events-none absolute inset-y-0 left-0 w-24 md:w-32 bg-gradient-to-r from-brand-bg to-transparent backdrop-blur-[2px]" style={{ WebkitMaskImage: "linear-gradient(to right, #000, transparent)", maskImage: "linear-gradient(to right, #000, transparent)" }} />
              <div className="pointer-events-none absolute inset-y-0 right-0 w-24 md:w-32 bg-gradient-to-l from-brand-bg to-transparent backdrop-blur-[2px]" style={{ WebkitMaskImage: "linear-gradient(to left, #000, transparent)", maskImage: "linear-gradient(to left, #000, transparent)" }} />
            </div>
          </div>

        </section>
      )}

      {service.slug === "solar-panel-cleaning" && <SolarFAQ />}

      {/* CTA */}
      <section className="bg-brand-bg py-20">
        <div className="section-container max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-5xl font-extrabold leading-tight">
            Ready for a{" "}
            <span className="text-teal-bright">spotless</span> finish?
          </h2>
          <p className="mt-4 text-white/70 font-light">
            Free quotes in under 24 hours. Fully insured. 100% satisfaction guaranteed.
          </p>
          <div className="mt-8 flex flex-wrap justify-center gap-4">
            <Link to="/" hash="contact" className="btn-teal text-sm px-6 py-3">
              Get My Free Quote <ArrowRight size={16} />
            </Link>
            <Link to="/" className="btn-ghost-light text-sm px-6 py-3">
              Explore other services
            </Link>
          </div>
          <div className="mt-10 flex flex-wrap justify-center gap-6 text-sm text-white/60">
            <span className="inline-flex items-center gap-2">
              <CheckCircle2 size={16} className="text-teal-bright" /> Licensed & Insured
            </span>
            <span className="inline-flex items-center gap-2">
              <CheckCircle2 size={16} className="text-teal-bright" /> Pure-Water System
            </span>
            <span className="inline-flex items-center gap-2">
              <CheckCircle2 size={16} className="text-teal-bright" /> Local Calgary Crew
            </span>
          </div>
        </div>
      </section>
      </div>
    </main>
  );
}

function SolarFAQ() {
  const qs = [
    { q: "Why should I have my solar panels professionally cleaned?", a: "Dirt, pollen, and environmental buildup reduce the amount of sunlight reaching your solar panels. Regular professional cleaning helps maximize efficiency while protecting the long-term appearance of your investment." },
    { q: "How often should solar panels be cleaned?", a: "Most Calgary homes benefit from professional cleaning once or twice per year, while homes near trees, construction, or busy roads may require more frequent service." },
    { q: "Can cleaning improve my solar panel performance?", a: "Yes. Removing dirt and debris allows more sunlight to reach the solar cells, helping your system operate closer to its designed efficiency." },
    { q: "Why doesn't BINS use soap or tap water?", a: "Our BINS Pure-Clean System™ produces 0 TDS ultra-pure water, allowing panels to dry naturally without mineral spots, soap residue, or streaks." },
    { q: "Is your cleaning process safe for my solar panels?", a: "Absolutely. We use soft water-fed brushes and purified water to safely clean your panels without harsh chemicals or abrasive tools. Our process is powered by the BINS Pure-Clean System™ — a premium 4-stage Reverse Osmosis & Deionization filtration system that purifies water to 0 Total Dissolved Solids (0 TDS). It's the same trusted system relied on by commercial buildings and countless solar homeowners across Calgary." },
    { q: "Will rain clean my solar panels?", a: "No. Rain may rinse away loose dust, but it won't remove pollen, bird droppings, or stubborn grime that can reduce your panels' performance." },
    { q: "Do you clean while the panels are turned on?", a: "Yes. Solar panels are designed to operate safely in daylight, and our cleaning methods are performed using industry-safe procedures." },
  ];
  const [open, setOpen] = useState<number | null>(0);
  return (
    <section id="faq" className="bg-brand-bg py-24 md:py-36">
      <div className="section-container max-w-3xl">
        <div className="text-center">
          <span className="text-xs font-semibold tracking-[0.25em] text-teal uppercase">FAQ</span>
          <h2 className="mt-4 text-4xl md:text-6xl text-white">
            Questions,
            <span className="text-teal"> answered.</span>
          </h2>
        </div>

        <div className="mt-12 flex flex-col gap-4">
          {qs.map((item, i) => {
            const isOpen = open === i;
            return (
              <div
                key={item.q}
                className={`rounded-2xl bg-card border transition-all duration-300 ${isOpen ? "border-teal shadow-[var(--shadow-soft)]" : "border-border"}`}
              >
                <button
                  onClick={() => setOpen(isOpen ? null : i)}
                  className="w-full flex items-center justify-between gap-4 px-6 py-6 text-left"
                >
                  <span className="text-base md:text-lg font-semibold text-white">{item.q}</span>
                  <ChevronDown
                    size={20}
                    className={`shrink-0 text-teal transition-transform duration-300 ${isOpen ? "rotate-180" : ""}`}
                  />
                </button>
                <div
                  className="grid transition-all duration-500 ease-out"
                  style={{ gridTemplateRows: isOpen ? "1fr" : "0fr" }}
                >
                  <div className="overflow-hidden">
                    <p className="px-6 pb-6 text-white/70 font-light leading-relaxed">
                      {item.a}
                    </p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
