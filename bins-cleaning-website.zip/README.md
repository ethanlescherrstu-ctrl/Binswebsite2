# BINS Cleaning website

Marketing site for BINS Cleaning (Calgary). Built with **TanStack Start + React 19 + Tailwind CSS 4**,
server-rendered by Nitro. Originally generated in Lovable; this repo is now fully standalone.

## Run it on your computer

Requires [Node.js](https://nodejs.org) 22 (20.19+ works).

```bash
npm install
npm run dev        # http://localhost:8080  (live-reloads as you edit)
```

Other commands: `npm run build` (production build) · `npm start` (run the build) ·
`npm run typecheck` · `npm run lint` · `npm run format`

## Where things live

| To change…                              | Edit                                             |
| --------------------------------------- | ------------------------------------------------ |
| Home page text, sections, pricing, FAQ  | `src/routes/index.tsx`                           |
| The 6 service pages (`/services/...`)   | `src/routes/services.$slug.tsx`                  |
| Page title / SEO description / fonts    | `src/routes/__root.tsx`                          |
| Colors, theme                           | `src/styles.css`                                 |
| Photos & videos                         | `public/media/` (see below) and `src/assets/`    |

## Photos & videos (important one-time setup)

Most images and all videos used to be stored in Lovable's cloud, not in the code. They must be
copied into this repo once. The list is in `scripts/media.manifest.json`.

```bash
npm run media:fetch -- https://YOUR-PROJECT.lovable.app   # download originals -> ./media-originals
npm run media:build                                       # web-optimize -> ./public/media
npm run media:check                                       # confirm nothing is missing
```

* `media:build` needs [ffmpeg](https://ffmpeg.org/download.html) to shrink videos
  (`brew install ffmpeg` · `winget install ffmpeg` · `sudo apt install ffmpeg`).
* If `media:fetch` can't download a file, save it by hand into `media-originals/` using the exact
  filename shown, then run `media:build`.
* Commit the resulting `public/media/` folder. Keep `media-originals/` out of git (already ignored).
* Later, to move media to a CDN/object storage, upload `public/media/*` there and set
  `VITE_MEDIA_BASE_URL` (see `.env.example`) — no code changes needed.

## Deploying (you choose the host)

The deploy target is picked at build time with `NITRO_PRESET` (default `node-server`).

**A. Easiest — Cloudflare** (free tier, global CDN, free HTTPS): build with
`NITRO_PRESET=cloudflare-module npm run build`, then connect this GitHub repo in Cloudflare
(Workers & Pages) using that build command. Videos work on iPhones out of the box.

**B. Your own server (VPS) with Docker** — full control:

```bash
docker compose up -d --build                              # site on port 80
SITE_ADDRESS=www.yourdomain.com docker compose up -d --build   # + automatic HTTPS
```

**C. Vercel / Netlify / Render / Railway** — set `NITRO_PRESET` to `vercel` or `netlify`, or use the
Node server (`npm run build && npm start`, port from `PORT`). See <https://nitro.build/deploy>.

> **Videos + Node server:** the plain Node server does not support HTTP range requests, which iPhones
> need to play `<video>`. On option B this is handled by Caddy (included). If you run `npm start`
> directly, put it behind Caddy/nginx/Cloudflare or host media on a CDN.

## Buying a domain later

Buy it anywhere (Cloudflare Registrar, Namecheap, Google/Squarespace Domains…), then point its DNS
at whichever host you chose above. Update the `og:` tags/URLs in `src/routes/__root.tsx` once you
have the final address.
