#!/usr/bin/env node
/**
 * Downloads the images/videos that were stored in Lovable's asset storage.
 *
 *   npm run media:fetch -- https://YOUR-PROJECT.lovable.app
 *
 * Use your Lovable *published* or *preview* URL (whichever loads your site).
 * Files land in ./media-originals (git-ignored). Then run `npm run media:build`.
 * Add --all to also fetch the 13 assets that no page currently uses.
 */
import { readFileSync, mkdirSync, existsSync, statSync, createWriteStream, unlinkSync } from "node:fs";
import { Readable } from "node:stream";
import { pipeline } from "node:stream/promises";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const args = process.argv.slice(2);
const all = args.includes("--all");
const base = args.find((a) => /^https?:\/\//.test(a))?.replace(/\/$/, "");

if (!base) {
  console.error("Usage: npm run media:fetch -- https://YOUR-PROJECT.lovable.app [--all]");
  process.exit(1);
}

const { items } = JSON.parse(readFileSync(join(root, "scripts/media.manifest.json"), "utf8"));
const wanted = items.filter((i) => all || i.used);
const outDir = join(root, "media-originals");
mkdirSync(outDir, { recursive: true });

let ok = 0, skipped = 0;
const failed = [];

for (const [n, it] of wanted.entries()) {
  const dest = join(outDir, it.original);
  const label = `[${n + 1}/${wanted.length}] ${it.original}`;
  if (existsSync(dest) && it.bytes && statSync(dest).size === it.bytes) {
    console.log(`${label}  already downloaded`);
    skipped++;
    continue;
  }
  const url = base + it.lovablePath;
  try {
    const res = await fetch(url);
    const type = res.headers.get("content-type") || "";
    // A missing file on a single-page site often returns 200 + an HTML page. Reject that.
    if (!res.ok || type.includes("text/html") || !res.body) {
      throw new Error(`HTTP ${res.status} (${type || "no content-type"})`);
    }
    await pipeline(Readable.fromWeb(res.body), createWriteStream(dest));
    const size = statSync(dest).size;
    if (it.bytes && size !== it.bytes) {
      console.warn(`${label}  downloaded, but size ${size} differs from expected ${it.bytes}`);
    } else {
      console.log(`${label}  ok (${(size / 1e6).toFixed(1)} MB)`);
    }
    ok++;
  } catch (err) {
    try { unlinkSync(dest); } catch {}
    console.error(`${label}  FAILED: ${err.message}`);
    failed.push(it.original);
  }
}

console.log(`\nDone. downloaded: ${ok}, already had: ${skipped}, failed: ${failed.length}`);
if (failed.length) {
  console.log("\nCould not download:\n  " + failed.join("\n  "));
  console.log("\nDownload those by hand from the Lovable editor and put them in ./media-originals/ using exactly these file names.");
  process.exit(1);
}
console.log("Next: npm run media:build");
