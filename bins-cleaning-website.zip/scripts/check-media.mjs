#!/usr/bin/env node
/** Verifies every media file the site references exists in public/media and looks sane. */
import { readFileSync, existsSync, statSync, openSync, readSync, closeSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const { items } = JSON.parse(readFileSync(join(root, "scripts/media.manifest.json"), "utf8"));
const problems = [];
let total = 0;

for (const it of items.filter((i) => i.used)) {
  const p = join(root, "public/media", it.web);
  if (!existsSync(p)) { problems.push(`MISSING   ${it.web}`); continue; }
  const size = statSync(p).size;
  total += size;
  const fd = openSync(p, "r"); const buf = Buffer.alloc(16); readSync(fd, buf, 0, 16, 0); closeSync(fd);
  if (size === 0 || buf.toString("utf8").trimStart().startsWith("<")) problems.push(`NOT MEDIA ${it.web} (empty or an HTML error page)`);
  else if (size > 50 * 1024 * 1024) problems.push(`TOO BIG   ${it.web} is ${(size / 1048576).toFixed(0)} MiB (GitHub warns above 50 MiB; slow for visitors)`);
}

console.log(`public/media total: ${(total / 1e6).toFixed(1)} MB`);
if (problems.length) { console.error("\n" + problems.join("\n")); process.exit(1); }
console.log("Media check passed: every referenced file is present.");
