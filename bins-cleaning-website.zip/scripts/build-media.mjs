#!/usr/bin/env node
/**
 * Turns ./media-originals into web-ready files in ./public/media
 *  - images are copied as-is
 *  - videos are re-encoded to H.264 MP4 (max 1920px long side, "faststart" so they
 *    begin playing before fully downloaded). Requires ffmpeg: https://ffmpeg.org/download.html
 *
 *   npm run media:build            (skips files that are already up to date)
 *   npm run media:build -- --force (redo everything)
 */
import { readFileSync, mkdirSync, existsSync, statSync, copyFileSync } from "node:fs";
import { spawnSync } from "node:child_process";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const force = process.argv.includes("--force");
const { items } = JSON.parse(readFileSync(join(root, "scripts/media.manifest.json"), "utf8"));
const srcDir = join(root, "media-originals");
const outDir = join(root, "public/media");
mkdirSync(outDir, { recursive: true });

const hasFfmpeg = spawnSync("ffmpeg", ["-version"], { stdio: "ignore" }).status === 0;
const mb = (p) => (statSync(p).size / 1e6).toFixed(1) + " MB";
let done = 0, missing = [], noFfmpeg = [];

for (const it of items.filter((i) => i.used)) {
  const src = join(srcDir, it.original);
  const out = join(outDir, it.web);
  if (!existsSync(src)) { missing.push(it.original); continue; }
  if (!force && existsSync(out) && statSync(out).mtimeMs >= statSync(src).mtimeMs) continue;

  if (it.type === "image") {
    copyFileSync(src, out);
    console.log(`image  ${it.web}  ${mb(out)}`);
  } else {
    if (!hasFfmpeg) { noFfmpeg.push(it.original); continue; }
    const r = spawnSync("ffmpeg", [
      "-y", "-loglevel", "error", "-i", src,
      "-vf", "scale='if(gt(iw,ih),min(1920,iw),min(1080,iw))':-2",
      "-c:v", "libx264", "-preset", "slow", "-crf", "26", "-pix_fmt", "yuv420p",
      "-c:a", "aac", "-b:a", "96k", "-movflags", "+faststart", out,
    ], { stdio: "inherit" });
    if (r.status !== 0) { console.error(`FAILED to convert ${it.original}`); process.exitCode = 1; continue; }
    console.log(`video  ${it.web}  ${mb(src)} -> ${mb(out)}`);
  }
  done++;
}

console.log(`\nProcessed ${done} file(s).`);
if (missing.length) console.log(`\nMissing from ./media-originals (${missing.length}):\n  ${missing.join("\n  ")}`);
if (noFfmpeg.length) {
  console.log(`\nffmpeg is not installed, so these videos were skipped:\n  ${noFfmpeg.join("\n  ")}`);
  console.log("Install it (macOS: brew install ffmpeg | Windows: winget install ffmpeg | Ubuntu: sudo apt install ffmpeg) and re-run.");
}
if (missing.length || noFfmpeg.length) process.exitCode = 1;
else console.log("All media ready. Verify with: npm run media:check");
