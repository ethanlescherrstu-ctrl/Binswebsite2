# What changed when leaving Lovable

| Change | Why |
| --- | --- |
| Removed `@lovable.dev/vite-tanstack-config`; `vite.config.ts` now lists the plugins explicitly | The wrapper locked builds to Lovable's Cloudflare setup. Same plugins, same behavior, your choice of host. |
| 50 `*.asset.json` stubs (37 actually used) replaced by `src/lib/media.ts` + real files in `public/media/` | Those stubs pointed at `/__l5e/assets-v1/...`, a URL only Lovable's servers answer. |
| Videos are served as web-optimized `.mp4` (were up to ~100 MB `.mov`) | Faster page loads; plays in every browser; fits comfortably in GitHub. |
| Removed `src/lib/lovable-error-reporting.ts` and its one call in `__root.tsx` | Sent errors to Lovable's editor; no-op elsewhere. Error page looks identical. |
| Removed `.lovable/`, `AGENTS.md`, `bun.lock`, `bunfig.toml`; added `package-lock.json` | Lovable-only files. One package manager (npm) avoids host confusion. |
| Fixed a TypeScript error in `__root.tsx` (`ErrorComponentProps`) | Existing bug that didn't affect the build but failed `npm run typecheck`. |
| Added README, Dockerfile, docker-compose, Caddyfile, CI workflow, `.env.example` | So the project can be built, hosted and checked without Lovable. |

Not changed: page content, design, routes, styling, and all UI components.
